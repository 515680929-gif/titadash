# TitaDashboard —— 特斯拉 iOS 仪表盘

一个仿「特别玩家 TPlayer / Dashla」的 iOS 仪表盘工程（SwiftUI），通过 **TITA 发射器**（第二路协议）实时读取特斯拉车辆数据，把手机变成横屏数字仪表屏。

> 本工程为完整可编译的源码包。由于 iOS 应用必须在 macOS + Xcode 中构建，本仓库提供全部源码与配置说明，你只需按下方「快速开始」创建 Xcode 工程并拖入源码即可运行。

---

## 功能一览

| 模块 | 说明 |
| --- | --- |
| 横屏仪表盘 | 深色主题、大圆环时速表、P/R/N/D 档位高亮、km/h 大字显示 |
| 行程面板 | 行驶时间、行驶距离、平均车速、本趟耗电（左侧栏，自动累计） |
| 车辆状态 | 电量百分比 + 电池条、预估续航、ODO 总里程 |
| 顶栏信息 | 当前时间、车外/车内温度、连接状态指示灯 |
| 音乐面板 | 右侧当前播放曲目/歌词区域（接入系统 Now Playing），双击切换歌词 |
| 左侧面板 | 双击循环切换：行程数据 → 地图+导航详情 → 四轮胎压/温度 |
| 导航详情 | ETA、剩余距离、到达预计电量、下一步转向、出口编号、当前路段名（叠加地图） |
| 胎压面板 | 四轮胎压(bar)+温度(℃)，异常胎压自动红色警示 |
| 测速增强 | 距离倒数浮窗、拍摄方向箭头、当前车速、超速变红+闪动边框、区间测速占位 |
| 车灯联动 | 地图车标实时显示大灯/刹车灯/转向灯/双闪；顶栏大灯/双闪/安全带/车门警示 |
| 发射器连接 | Wi-Fi 直连 `TITA_SENDER` 热点，WebSocket 实时数据流，自动重连 |
| 配对引导页 | 三步引导：OTA 固件 → 开启第二路协议 → 点击测试连接 |
| 模拟器模式 | 无硬件时一键开启模拟数据，方便 UI 调试 |

## 工作原理

```
特斯拉 CAN 总线 ──> TITA 发射器(OBD 对插) ──Wi-Fi 热点 TITA_SENDER──> iPhone
                                              密码: TSLA1234
                                              网关: 4.3.2.1
                                              第二路协议(WebSocket/UDP)
```

- TITA 发射器对插特斯拉预留 OBD 接口，**只读取、不写入**车辆数据，不影响原车系统。
- 发射器固件 **≥ 1.66**，并在 OTA 页面（连接 `TITA_SENDER` 热点后浏览器访问 `4.3.2.1` 或 http://m.hitita.cc/sender/）中**开启「第二路协议」**。
- App 通过 `Network.framework` 建立 WebSocket 长连接，接收约 50ms 一帧的车辆数据，解析后驱动 UI。

### ⚠️ 关于协议字段（重要）

TITA 官方**未公开**第二路协议的完整字段文档。本工程采用「协议适配层」设计：

- `Network/TitaProtocol.swift` 中定义了 `TitaFrame` 解码结构与字段映射表，默认按 JSON 帧解析（key 可在 `FieldKey` 枚举中集中修改）。
- 首次真机联调时，用 App 内「连接测试」页的**原始数据日志**观察发射器实际推送的帧格式，然后把真实 key 填进 `FieldKey` 即可完成适配，无需改动其他代码。
- 若实际为二进制帧，同样在 `TitaFrameParser` 中按字节偏移解析即可（已预留入口）。
- **新增字段（需真机确认 key）**：`tpms_temp`（胎压温度）、`headlight`（大灯）、`hazard`（双闪）、`nav_eta`/`nav_remain`/`nav_arrival_soc`/`nav_road`/`nav_turn`/`nav_exit`（导航详情）。导航数据部分车型可能不是发射器推送、而来自车机 BLE，届时按实际日志调整。

## 工程结构

```
TitaDashboard/
├── TitaDashboardApp.swift          # App 入口
├── Theme/
│   └── DashboardTheme.swift        # 颜色/字体/布局常量
├── Models/
│   ├── VehicleState.swift          # 全局车辆状态（@Observable）
│   └── AppSettings.swift           # 全部设置项（UserDefaults 持久化）
├── Network/
│   ├── TitaProtocol.swift          # 帧模型 + 解析器 + 字段映射（重点适配处）
│   ├── TitaConnectionManager.swift # WebSocket 连接管理、心跳、自动重连
│   └── VehicleSimulator.swift      # 模拟数据源（开发调试用）
├── Services/
│   ├── LocationService.swift       # 手机 GPS（CoreLocation）
│   ├── NowPlayingService.swift     # 当前播放信息（含私有 API 风险提示）
│   ├── LyricsService.swift         # LRCLIB 同步歌词（免费公开 API）
│   └── SpeedCameraService.swift    # 测速点数据库 + 距离/方向触发 + 播报
├── Views/
│   ├── RootView.swift              # 根路由 + 服务装配
│   ├── DashboardView.swift         # 横屏仪表盘主页（地图背景层/HUD 镜像）
│   ├── MapPanelView.swift          # 苹果地图（跟随/车头朝上/自动缩放/车标）
│   ├── SpeedDialView.swift         # 圆环时速表 + PRND + 刹车弧/盲点/限速/红绿灯
│   ├── StatsPanelView.swift        # 左侧行程统计
│   ├── MusicPanelView.swift        # 右侧音乐 + 同步歌词
│   ├── SpeedCamAlertCardView.swift # 测速提醒卡片
│   ├── TopStatusBarView.swift      # 顶部状态栏
│   ├── ConnectionView.swift        # 发射器配对引导 + 连接测试
│   └── SettingsView.swift          # 设置页（深色分组卡片，全设置项）
└── Info.plist.snippet              # 需要合并进 Info.plist 的权限声明
```

## 新增能力说明（v2）

| 功能 | 实现 | 备注 |
| --- | --- | --- |
| 苹果地图 | MapKit（`MapPanelView`），跟随定位、车头朝上、按速度自动缩放、2D/3D、车标样式（含车型素材占位） | 国区苹果地图数据来自高德；Google 地图需另接 Google Maps SDK 且国内不可用 |
| 歌词显示 | LRCLIB 公开 API（`LyricsService`），LRC 逐行同步 | 读取「其他 App 正在播放」需私有 API（已在 `NowPlayingService` 中注释说明，**有审核风险**，默认关闭） |
| 测速照相 | `SpeedCameraService`：CSV 导入点位 → GPS 距离+方向匹配 → 卡片+音效/语音播报 | 点位数据需自备（设置页可导入 CSV，格式见代码注释） |
| TITA 专属信号 | 刹车弧灯、盲点警示（常亮/呼吸、始终/打灯时）、转向灯弧形、限速牌、超速闪烁、红绿灯、安全带 | 字段已加入 `TitaProtocol.FieldKey`，key 名需真机联调确认 |
| 全部设置项 | 主题/显示大小/驾驶侧/HUD/刷新模式/语音音量/方向/时速表样式与颜色/地图/导航图标/歌词/测速/单位/TITA | 全部持久化，UI 为截图同款深色胶囊分段控件 |

### 暂不可行 / 有前提的功能

- **后台显示-PiP**：iOS 的 PiP 仅面向视频内容，Dashla 等应用通过隐形视频取巧实现，**App Store 审核有拒审风险**，本工程未实现；灵动岛（ActivityKit Live Activities）是合规替代方案，可按需添加。
- **车机 GPS / Fusion GPS**：需特斯拉 BLE 协议读取车辆定位，工作量大，已在设置中标注「开发中」。
- **Musixmatch 歌词**：其 API 为付费商用授权，默认用免费的 LRCLIB；拿到授权 key 后在 `LyricsService` 中扩展即可。

## 快速开始

### 方式一：GitHub 云端打包 IPA（无需 Mac，推荐）

> ⚠️ IPA 的编译只能在 macOS 上完成（Apple 硬性限制，任何 Linux/Windows 都不行）。此方式借用 GitHub 的免费 macOS 云端编译器。

1. 在 GitHub 新建仓库（Public 仓库 Actions 免费）
2. 把本目录**所有文件**（含 `.github/` 和 `project.yml`）push 到仓库
3. 打开仓库 **Actions** 标签页，等待「Build Unsigned IPA」工作流完成（首次约 10~15 分钟）
4. 在运行结果页底部下载 Artifact `TitaDashboard-unsigned-ipa`
5. 自签安装（任选其一，免费 Apple ID 即可，证书 7 天有效）：
   - **Sideloadly**（Win/Mac，拖入 IPA + 输入 Apple ID）
   - **AltStore / SideStore**（Mac/PC 装服务端，手机端续签）
   - **爱思助手** → 工具箱 → IPA 签名（Win，国内用户方便）

### 方式二：本地 Mac 编译

```bash
brew install xcodegen
xcodegen generate        # 生成 TitaDashboard.xcodeproj
open TitaDashboard.xcodeproj
```

在 Xcode 中选择你的开发者账号签名，连上 iPhone 直接 Run（工程已内置 Info.plist，无需手动配置权限）。

### 真机测试

1. 手机 Wi-Fi 连接 `TITA_SENDER`（密码 `TSLA1234`）
2. 打开 App → 设置 → 发射器配对 → 点击测试
3. 没有硬件时：设置页打开「模拟器模式」，仪表盘会显示动态模拟数据

## 使用说明

- 仪表盘默认横屏全屏，隐藏系统状态栏，保持屏幕常亮。
- 左上/右上可进入设置与配对页。
- 行驶时间/距离/平均车速/本趟耗电在档位离开 P 档后开始累计，回 P 档自动结束本趟。

## 免责声明

本项目仅供学习交流，与 TITA、特别玩家、Dashla、Tesla 官方无任何关联。车辆数据接口属于各厂商私有协议，请勿用于商业用途或违反相关服务条款的场景。
