import Foundation
import SwiftUI
import CoreBluetooth

struct VehicleSnapshot {
    var speed: Double = 0
    var battery: Double = 82
    var range: Double = 438
    var outsideTemp: Double = 21
    var batteryTemp: Double = 28
    var motorTemp: Double = 34
    var frontLeftPressure: Double = 2.9
    var frontRightPressure: Double = 2.9
    var rearLeftPressure: Double = 3.0
    var rearRightPressure: Double = 3.0
    var frontLeftTemp: Double = 31
    var frontRightTemp: Double = 32
    var rearLeftTemp: Double = 33
    var rearRightTemp: Double = 33
    var odometer: Double = 12860.4
    var tripDistance: Double = 18.6
    var averageConsumption: Double = 146
    var gForce: Double = 0.04
    var isCharging: Bool = false
    var isLocked: Bool = true
    var leftSignal: Bool = false
    var rightSignal: Bool = false
    var blindSpotLeft: Bool = false
    var blindSpotRight: Bool = false
    var seatbelt: Bool = true
    var parkingBrake: Bool = true
}

@MainActor final class VehicleStore: ObservableObject {
    @Published var data = VehicleSnapshot()
    @Published var isDemoMode = true
    @Published var isScanning = false
    @Published var bluetoothState = "未连接"
    @Published var selectedVehicle = "Model 3 Performance"
    @Published var unit = "km/h"
    @Published var demoEnabled = true
    @Published var showAdvanced = true
    private var timer: Timer?
    private var phase = 0.0
    init() { startDemo() }
    func startDemo() {
        timer?.invalidate()
        guard demoEnabled else { data.speed = 0; return }
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                self.phase += 0.18
                self.data.speed = max(0, 76 + 35 * sin(self.phase))
                self.data.gForce = 0.12 * sin(self.phase * 1.7)
                self.data.leftSignal = Int(self.phase * 2) % 16 < 2
                self.data.rightSignal = Int(self.phase * 2 + 8) % 16 < 2
                self.data.battery = 82 - max(0, self.phase.truncatingRemainder(dividingBy: 70)) * 0.015
            }
        }
    }
    func toggleDemo() { demoEnabled.toggle(); isDemoMode = demoEnabled; startDemo() }
    func scanTITA() {
        isScanning = true
        bluetoothState = "正在搜索 TITA…"
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [weak self] in
            Task { @MainActor in
                self?.isScanning = false
                self?.bluetoothState = "未发现设备 · 演示模式"
            }
        }
    }
}
