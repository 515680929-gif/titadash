import Foundation
import MediaPlayer
import Observation

/// 当前播放信息 + 歌词联动。
///
/// ⚠️ 重要限制（iOS 公开 API）：
/// - `MPMusicPlayerController.systemMusicPlayer` 只能可靠读取「本 App 控制」的播放队列。
/// - 读取其他 App（Apple Music / QQ 音乐 / 网易云）的正在播放，公开 API 不开放。
///   Dashla 类应用使用的是私有框架 MediaRemote（MRMediaRemoteGetNowPlayingInfo），
///   技术上可行但存在 App Store 审核被拒风险，本工程默认不集成，
///   如需集成可在 `loadPrivateMediaRemote()` 中开启并自行评估风险。
@Observable
final class NowPlayingService {
    private(set) var title: String? = nil
    private(set) var artist: String? = nil
    private(set) var album: String? = nil
    private(set) var duration: TimeInterval = 0
    private(set) var playbackTime: TimeInterval = 0
    private(set) var isPlaying = false

    let lyrics = LyricsService()
    private var timer: Timer?
    var lyricsBaseURL: String = "https://lrclib.net" {
        didSet { lyrics.baseURL = lyricsBaseURL }
    }

    func start() {
        NotificationCenter.default.addObserver(
            self, selector: #selector(nowPlayingChanged),
            name: .MPMusicPlayerControllerNowPlayingItemDidChange, object: nil)
        MPMusicPlayerController.systemMusicPlayer.beginGeneratingPlaybackNotifications()
        refresh()

        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            self?.tickPlaybackTime()
        }
        lyrics.startSync { [weak self] in self?.playbackTime ?? 0 }
    }

    func stop() {
        timer?.invalidate(); timer = nil
        lyrics.stop()
        MPMusicPlayerController.systemMusicPlayer.endGeneratingPlaybackNotifications()
        NotificationCenter.default.removeObserver(self)
    }

    @objc private func nowPlayingChanged() { refresh() }

    private func refresh() {
        let item = MPMusicPlayerController.systemMusicPlayer.nowPlayingItem
        title = item?.title
        artist = item?.artist
        album = item?.albumTitle
        duration = item?.playbackDuration ?? 0
        if let t = item?.title, let a = item?.artist {
            lyrics.fetch(track: t, artist: a, album: item?.albumTitle,
                         duration: item?.playbackDuration)
        } else {
            lyrics.stop()
        }
    }

    private func tickPlaybackTime() {
        let player = MPMusicPlayerController.systemMusicPlayer
        isPlaying = player.playbackState == .playing
        playbackTime = player.currentPlaybackTime
    }

    // MARK: - 私有 API 入口（默认关闭，自行评估审核风险）
    /*
    private func loadPrivateMediaRemote() {
        guard let bundle = CFBundleCreate(
            kCFAllocatorDefault,
            NSURL(fileURLWithPath: "/System/Library/PrivateFrameworks/MediaRemote.framework"))
        else { return }
        typealias GetInfoFunc = @convention(c) (DispatchQueue, @escaping ([String: Any]) -> Void) -> Void
        guard let ptr = CFBundleGetFunctionPointerForName(
            bundle, "MRMediaRemoteGetNowPlayingInfo" as CFString) else { return }
        let getInfo = unsafeBitCast(ptr, to: GetInfoFunc.self)
        getInfo(.main) { info in
            self.title = info["kMRMediaRemoteNowPlayingInfoTitle"] as? String
            self.artist = info["kMRMediaRemoteNowPlayingInfoArtist"] as? String
            // ...
        }
    }
    */
}
