import Foundation
import Observation

/// 歌词服务：默认接入 LRCLIB（免费开源歌词库，无需 API Key）。
/// API 文档：https://lrclib.net/docs
@Observable
final class LyricsService {
    private(set) var lines: [(time: TimeInterval, text: String)] = []
    private(set) var currentLine: String? = nil
    private(set) var isLoading = false

    private var currentTrackID: String? = nil
    private var timer: Timer?
    var baseURL: String = "https://lrclib.net"   // 对应设置里的「数据库网址」

    /// 歌曲切换时调用，拉取同步歌词
    func fetch(track: String, artist: String, album: String? = nil, duration: TimeInterval? = nil) {
        let trackID = "\(artist)-\(track)"
        guard trackID != currentTrackID else { return }
        currentTrackID = trackID
        lines = []
        currentLine = nil
        isLoading = true

        var comps = URLComponents(string: baseURL + "/api/get")!
        var query = [
            URLQueryItem(name: "track_name", value: track),
            URLQueryItem(name: "artist_name", value: artist)
        ]
        if let album { query.append(URLQueryItem(name: "album_name", value: album)) }
        if let duration { query.append(URLQueryItem(name: "duration", value: String(Int(duration)))) }
        comps.queryItems = query

        Task { [weak self] in
            guard let self else { return }
            defer { Task { @MainActor in self.isLoading = false } }
            do {
                let (data, _) = try await URLSession.shared.data(from: comps.url!)
                let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                // syncedLyrics 为 LRC 格式；无同步歌词时退化为纯文本 plainLyrics
                if let lrc = obj?["syncedLyrics"] as? String {
                    let parsed = Self.parseLRC(lrc)
                    await MainActor.run { self.lines = parsed }
                } else if let plain = obj?["plainLyrics"] as? String {
                    let parsed = plain.components(separatedBy: .newlines)
                        .filter { !$0.isEmpty }
                        .map { (TimeInterval.zero, $0) }
                    await MainActor.run { self.lines = parsed }
                }
            } catch {
                // 无歌词或网络失败：保持「无法取得歌词」占位
            }
        }
    }

    /// 根据播放进度启动逐行高亮（0.5s 粒度）
    func startSync(playbackTime: @escaping () -> TimeInterval) {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self, !self.lines.isEmpty else { return }
            let t = playbackTime()
            let current = self.lines.last(where: { $0.time <= t })?.text
            if current != self.currentLine {
                Task { @MainActor in self.currentLine = current }
            }
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
        lines = []
        currentLine = nil
        currentTrackID = nil
    }

    /// 解析 LRC 格式：[mm:ss.xx]歌词
    static func parseLRC(_ lrc: String) -> [(time: TimeInterval, text: String)] {
        var result: [(TimeInterval, String)] = []
        let pattern = #"\[(\d+):(\d+(?:\.\d+)?)\]"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }

        for line in lrc.components(separatedBy: .newlines) {
            let ns = line as NSString
            let matches = regex.matches(in: line, range: NSRange(location: 0, length: ns.length))
            guard !matches.isEmpty else { continue }
            let text = ns.replacingOccurrences(of: pattern, with: "", options: .regularExpression)
                .trimmingCharacters(in: .whitespaces)
            guard !text.isEmpty else { continue }
            for m in matches {
                let min = Double(ns.substring(with: m.range(at: 1))) ?? 0
                let sec = Double(ns.substring(with: m.range(at: 2))) ?? 0
                result.append((min * 60 + sec, text))
            }
        }
        return result.sorted { $0.0 < $1.0 }
    }
}
