import Foundation
import CoreLocation
import AVFoundation
import Observation

/// 测速点数据模型
struct SpeedCamera: Identifiable {
    enum CamType: String, CaseIterable {
        case fixed = "固定测速", mobile = "移动测速"
        case tech = "科技执法", section = "区间测速"
    }
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
    let type: CamType
    let speedLimit: Int           // km/h
    let direction: Double?        // 监测方向（度），nil 表示双向
}

/// 当前触发的提醒
struct SpeedCamAlert: Equatable {
    let cameraID: UUID
    let type: SpeedCamera.CamType
    let distanceMeters: Int
    let speedLimit: Int
    let isOverspeed: Bool
}

/// 测速照相提醒服务：
/// - 数据源：本地 CSV 导入（lat,lon,type,limit,direction），或远程图资自动更新
/// - 触发逻辑：按 GPS 位置计算与测速点距离 + 行进方向匹配
@Observable
final class SpeedCameraService {
    private(set) var cameras: [SpeedCamera] = []
    private(set) var currentAlert: SpeedCamAlert? = nil
    private(set) var dataVersion: String = "未导入"

    /// 触发提醒的距离阈值（米）
    var alertDistance: Double = 500
    /// 方向匹配容差（度）：测速点方向与行进方向夹角小于该值才提醒
    var directionTolerance: Double = 45

    private var audioPlayer: AVAudioPlayer?
    private var lastAlertedCamera: UUID? = nil
    private let synthesizer = AVSpeechSynthesizer()
    var voiceVolume: Float = 0.4

    // MARK: - 数据导入

    /// 从 CSV 文本导入：每行 "纬度,经度,类型(fixed/mobile/tech/section),限速,方向(可空)"
    @discardableResult
    func importCSV(_ csv: String, version: String? = nil) -> Int {
        var imported: [SpeedCamera] = []
        for line in csv.components(separatedBy: .newlines) {
            let cols = line.components(separatedBy: ",").map {
                $0.trimmingCharacters(in: .whitespaces)
            }
            guard cols.count >= 4,
                  let lat = Double(cols[0]), let lon = Double(cols[1]),
                  let type = SpeedCamera.CamType(rawValue: cols[2]),
                  let limit = Int(cols[3])
            else { continue }
            let dir = cols.count > 4 ? Double(cols[4]) : nil
            imported.append(SpeedCamera(
                coordinate: CLLocationCoordinate2D(latitude: lat, longitude: lon),
                type: type, speedLimit: limit, direction: dir))
        }
        if !imported.isEmpty {
            cameras = imported
            if let version { dataVersion = version }
        }
        return imported.count
    }

    /// 从远程图资 URL 更新（设置中「自动更新」）
    func updateFromRemote(url: URL) async throws {
        let (data, _) = try await URLSession.shared.data(from: url)
        if let csv = String(data: data, encoding: .utf8) {
            let count = importCSV(csv, version: Self.todayVersion())
            if count == 0 { throw URLError(.cannotParseResponse) }
        }
    }

    static func todayVersion() -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy.M.d"
        return f.string(from: Date())
    }

    // MARK: - 逐帧检查（由位置更新驱动，1~2Hz 即可）

    func check(location: CLLocationCoordinate2D, heading: Double,
               speedKmh: Double, settings: AppSettings) {
        guard settings.speedCamEnabled, !cameras.isEmpty else {
            currentAlert = nil
            return
        }

        // 按设置过滤类型
        let allowed = cameras.filter { cam in
            switch cam.type {
            case .fixed:   return settings.speedCamFixed
            case .mobile:  return settings.speedCamMobile
            case .tech:    return settings.speedCamTech
            case .section: return settings.speedCamSection
            }
        }

        // 找最近的匹配点
        var best: (SpeedCamera, Double)? = nil
        let userLoc = CLLocation(latitude: location.latitude, longitude: location.longitude)
        for cam in allowed {
            let dist = userLoc.distance(from: CLLocation(
                latitude: cam.coordinate.latitude, longitude: cam.coordinate.longitude))
            guard dist <= alertDistance else { continue }
            // 方向匹配：点了监测方向才校验
            if let camDir = cam.direction {
                let diff = abs((heading - camDir).truncatingRemainder(dividingBy: 360))
                let angle = min(diff, 360 - diff)
                guard angle <= directionTolerance else { continue }
            }
            if best == nil || dist < best!.1 { best = (cam, dist) }
        }

        guard let (cam, dist) = best else {
            currentAlert = nil
            lastAlertedCamera = nil
            return
        }

        // 超速判断
        let overspeed: Bool
        switch settings.speedCamThresholdMode {
        case .fixed:
            overspeed = speedKmh > Double(cam.speedLimit) + settings.speedCamThresholdValue
        case .percent:
            overspeed = speedKmh > Double(cam.speedLimit) * (1 + settings.speedCamThresholdValue / 100)
        }

        // 提醒时机
        if settings.speedCamTiming == .overspeed, !overspeed {
            currentAlert = nil
            return
        }

        let alert = SpeedCamAlert(
            cameraID: cam.id, type: cam.type,
            distanceMeters: Int(dist), speedLimit: cam.speedLimit,
            isOverspeed: overspeed)
        currentAlert = alert

        // 音效/语音：进入新测速点范围时播报一次
        if lastAlertedCamera != cam.id {
            lastAlertedCamera = cam.id
            announce(alert: alert, settings: settings)
        }
    }

    // MARK: - 播报

    private func announce(alert: SpeedCamAlert, settings: AppSettings) {
        guard settings.speedCamSound else { return }
        if settings.speedCamPassNotice == .voice {
            let text = "前方\(alert.distanceMeters)米，\(alert.type.rawValue)，限速\(alert.speedLimit)"
            let utt = AVSpeechUtterance(string: text)
            utt.voice = AVSpeechSynthesisVoice(language: "zh-CN")
            utt.volume = voiceVolume
            synthesizer.speak(utt)
        } else {
            // 音效：系统提示音（可替换为自定义音频文件）
            AudioServicesPlaySystemSound(1052)
        }
    }
}
