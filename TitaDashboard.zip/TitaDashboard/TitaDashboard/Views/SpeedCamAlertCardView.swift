import SwiftUI

/// 测速提醒卡片：叠加在仪表盘上，超速时变红
struct SpeedCamAlertCardView: View {
    let alert: SpeedCamAlert

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: iconName)
                .font(.system(size: 24))
                .foregroundStyle(alert.isOverspeed ? .white : DashboardTheme.accentOrange)

            VStack(alignment: .leading, spacing: 2) {
                Text(alert.type.rawValue)
                    .font(.system(size: 15, weight: .semibold))
                Text("限速 \(alert.speedLimit) · \(alert.distanceMeters)m")
                    .font(DashboardTheme.monoDigit(size: 14))
                    .opacity(0.85)
            }
            Spacer()
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(alert.isOverspeed
                      ? Color.red.opacity(0.85)
                      : Color(white: 0.12).opacity(0.92))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.white.opacity(0.15), lineWidth: 1)
        )
        .transition(.move(edge: .top).combined(with: .opacity))
    }

    private var iconName: String {
        switch alert.type {
        case .fixed, .mobile: return "camera.fill"
        case .tech:           return "antenna.radiowaves.left.and.right"
        case .section:        return "road.lanes"
        }
    }
}
