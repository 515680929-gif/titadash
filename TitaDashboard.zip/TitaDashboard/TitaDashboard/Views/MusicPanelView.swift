import SwiftUI

/// 右侧音乐面板：默认显示当前播放歌曲，双击切换显示同步歌词（LRCLIB 免费源）
struct MusicPanelView: View {
    let nowPlaying: NowPlayingService
    /// 双击在「歌曲信息 / 歌词」之间切换
    @State private var showLyrics = false

    var body: some View {
        ZStack {
            if showLyrics {
                lyricsView
            } else {
                musicView
            }
        }
        .frame(maxWidth: 220, minHeight: 220)
        .contentShape(Rectangle())
        .onTapGesture(count: 2) {
            withAnimation(.easeInOut(duration: 0.25)) {
                showLyrics.toggle()
            }
        }
        .onAppear { nowPlaying.start() }
        .onDisappear { nowPlaying.stop() }
    }

    // MARK: - 歌曲信息（默认）
    private var musicView: some View {
        VStack(spacing: 12) {
            // 音乐图标（仿截图中的音符卡片）
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(DashboardTheme.panelBackground)
                Image(systemName: "music.note")
                    .font(.system(size: 44, weight: .light))
                    .foregroundStyle(DashboardTheme.secondaryText)
            }
            .frame(width: 140, height: 140)

            if let title = nowPlaying.title {
                Text(title)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(DashboardTheme.primaryText)
                    .lineLimit(1)
                if let artist = nowPlaying.artist {
                    Text(artist)
                        .font(.system(size: 14))
                        .foregroundStyle(DashboardTheme.secondaryText)
                        .lineLimit(1)
                }
            } else {
                Text("未在播放")
                    .font(.system(size: 16))
                    .foregroundStyle(DashboardTheme.secondaryText)
            }
        }
    }

    // MARK: - 同步歌词（双击后显示）
    private var lyricsView: some View {
        VStack(spacing: 10) {
            Image(systemName: "list.bullet")
                .font(.system(size: 24))
                .foregroundStyle(DashboardTheme.secondaryText)

            if let title = nowPlaying.title {
                Text(title)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(DashboardTheme.secondaryText)
                    .lineLimit(1)
            }

            // 当前歌词行；取自设置中配置的免费歌词源（LRCLIB）
            Text(nowPlaying.lyrics.currentLine ?? "无法取得歌词")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(nowPlaying.lyrics.currentLine != nil
                                 ? DashboardTheme.primaryText
                                 : DashboardTheme.secondaryText)
                .multilineTextAlignment(.center)
                .lineLimit(3)
                .animation(.easeInOut(duration: 0.3),
                           value: nowPlaying.lyrics.currentLine)
        }
        .frame(maxWidth: 220, minHeight: 220)
    }
}
