import SwiftUI

/// 右侧音乐面板：曲名/歌手 + 同步歌词（LRCLIB）
struct MusicPanelView: View {
    let nowPlaying: NowPlayingService

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "list.bullet")
                .font(.system(size: 28))
                .foregroundStyle(DashboardTheme.secondaryText)
                .overlay(alignment: .bottomTrailing) {
                    Image(systemName: "music.note")
                        .font(.system(size: 13))
                        .foregroundStyle(DashboardTheme.secondaryText)
                        .offset(x: 7, y: 4)
                }

            if let title = nowPlaying.title {
                Text(title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(DashboardTheme.primaryText)
                    .lineLimit(1)
                if let artist = nowPlaying.artist {
                    Text(artist)
                        .font(.system(size: 13))
                        .foregroundStyle(DashboardTheme.secondaryText)
                        .lineLimit(1)
                }
                // 同步歌词当前行；无歌词时显示占位
                Text(nowPlaying.lyrics.currentLine ?? "无法取得歌词")
                    .font(.system(size: 14))
                    .foregroundStyle(nowPlaying.lyrics.currentLine != nil
                                     ? DashboardTheme.primaryText
                                     : DashboardTheme.secondaryText)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
                    .animation(.easeInOut(duration: 0.3),
                               value: nowPlaying.lyrics.currentLine)
            } else {
                Text("无法取得歌词")
                    .font(.system(size: 15))
                    .foregroundStyle(DashboardTheme.secondaryText)
            }
        }
        .frame(maxWidth: 190)
        .onAppear { nowPlaying.start() }
        .onDisappear { nowPlaying.stop() }
    }
}
