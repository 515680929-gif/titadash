import SwiftUI

/// 顶部状态栏：时间、车内外温度、连接状态、设置入口
struct TopStatusBarView: View {
    @Environment(VehicleState.self) private var vehicleState
    @Environment(TitaConnectionManager.self) private var connectionManager

    var onOpenSettings: () -> Void
    var onOpenConnection: () -> Void

    @State private var now = Date()
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        HStack(spacing: 18) {
            // 时间
            Text(now, format: .dateTime.hour().minute())
                .font(DashboardTheme.monoDigit(size: 22, weight: .bold))
                .foregroundStyle(DashboardTheme.primaryText)

            // 车外温度
            Label(tempText(vehicleState.outsideTempC), systemImage: "cloud.sun")
                .font(.system(size: 15))
                .foregroundStyle(DashboardTheme.secondaryText)

            // 车内温度
            Label(tempText(vehicleState.insideTempC), systemImage: "car.side")
                .font(.system(size: 15))
                .foregroundStyle(DashboardTheme.secondaryText)

            // 连接状态点
            Circle()
                .fill(statusColor)
                .frame(width: 10, height: 10)

            Spacer()

            // AP / 电量小标
            if vehicleState.autopilotActive {
                Image(systemName: "steeringwheel")
                    .foregroundStyle(.blue)
            }

            // 配对入口
            Button(action: onOpenConnection) {
                Image(systemName: "antenna.radiowaves.left.and.right")
                    .font(.system(size: 18))
                    .foregroundStyle(DashboardTheme.secondaryText)
            }

            // 设置入口
            Button(action: onOpenSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18))
                    .foregroundStyle(DashboardTheme.secondaryText)
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 10)
        .onReceive(ticker) { now = $0 }
    }

    private var statusColor: Color {
        switch connectionManager.status {
        case .connected:    return DashboardTheme.accentGreen
        case .connecting:   return DashboardTheme.accentOrange
        default:            return DashboardTheme.placeholder
        }
    }

    private func tempText(_ c: Double?) -> String {
        guard let c else { return "--°C" }
        return String(format: "%.0f°C", c)
    }
}
