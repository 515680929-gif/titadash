import SwiftUI

/// 左侧行程统计面板：行驶时间 / 行驶距离 / 平均车速 / 本趟耗电
struct StatsPanelView: View {
    @Environment(VehicleState.self) private var vehicleState
    let now: Date

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            statItem(title: "行驶时间", value: durationText)
            statItem(title: "行驶距离", value: distanceText)
            statItem(title: "平均车速", value: avgSpeedText)
            statItem(title: "本趟耗电 ⚡", value: energyText)
        }
    }

    private func statItem(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 15))
                .foregroundStyle(DashboardTheme.secondaryText)
            Text(value)
                .font(DashboardTheme.monoDigit(size: 20))
                .foregroundStyle(DashboardTheme.primaryText)
        }
    }

    private var durationText: String {
        let t = vehicleState.tripDuration
        guard t > 0 else { return "--" }
        let h = Int(t) / 3600, m = (Int(t) % 3600) / 60, s = Int(t) % 60
        return h > 0
            ? String(format: "%d:%02d:%02d", h, m, s)
            : String(format: "%02d:%02d", m, s)
    }

    private var distanceText: String {
        vehicleState.tripDistanceKm > 0
            ? String(format: "%.1f km", vehicleState.tripDistanceKm)
            : "--"
    }

    private var avgSpeedText: String {
        guard let avg = vehicleState.tripAverageSpeedKmh, avg > 0 else { return "--" }
        return String(format: "%.0f km/h", avg)
    }

    private var energyText: String {
        vehicleState.tripEnergyKwh > 0
            ? String(format: "%.2f kWh", vehicleState.tripEnergyKwh)
            : "--"
    }
}
