import SwiftUI

/// 发射器配对引导页（仿截图）：三步引导 + 连接测试 + 原始数据日志
struct ConnectionView: View {
    @Environment(TitaConnectionManager.self) private var connectionManager
    @AppStorage("titaHost") private var host = "4.3.2.1"
    @AppStorage("titaPort") private var port = 8080

    var onBack: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    stepOne
                    stepTwo
                    stepThree
                    debugSection
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("发射器模式配对")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: onBack) {
                        Image(systemName: "chevron.left")
                    }
                }
            }
        }
        .preferredColorScheme(.light)
    }

    // MARK: - 第一步：OTA 固件
    private var stepOne: some View {
        VStack(alignment: .leading, spacing: 12) {
            stepHeader("第一步：OTA 发射器到 1.66 版本以上")

            VStack(alignment: .leading, spacing: 8) {
                Text("手机 Wi-Fi 连接 **TITA_SENDER**（密码 TSLA1234），点击下面链接把发射器 OTA 到 1.66 以上：")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Link("http://m.hitita.cc/sender/",
                     destination: URL(string: "http://m.hitita.cc/sender/")!)
                    .font(.subheadline)
                Text("若页面无法打开，浏览器直接访问 4.3.2.1")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .cardStyle()
        }
    }

    // MARK: - 第二步：开启第二路协议
    private var stepTwo: some View {
        VStack(alignment: .leading, spacing: 12) {
            stepHeader("第二步：开启第二路协议")

            VStack(alignment: .leading, spacing: 8) {
                Text("在发射器 OTA 网页的「自定义设置」中：")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Label("找到「第二路协议」，点击「开启」", systemImage: "1.circle.fill")
                Label("其他选项保持默认，无需修改", systemImage: "2.circle.fill")
                Label("保存后发射器会自动重启", systemImage: "3.circle.fill")
                    .font(.subheadline)
            }
            .font(.subheadline)
            .cardStyle()
        }
    }

    // MARK: - 第三步：连接测试
    private var stepThree: some View {
        VStack(alignment: .leading, spacing: 12) {
            stepHeader("第三步：连接发射器")

            VStack(spacing: 14) {
                HStack {
                    TextField("发射器地址", text: $host)
                        .keyboardType(.decimalPad)
                        .textFieldStyle(.roundedBorder)
                    TextField("端口", value: $port, format: .number)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .frame(width: 90)
                }

                Button {
                    connectionManager.host = host
                    connectionManager.port = UInt16(clamping: port)
                    if connectionManager.status == .connected {
                        connectionManager.disconnect()
                    } else {
                        connectionManager.connect()
                    }
                } label: {
                    Text(connectionManager.status == .connected ? "断开连接" : "点击测试")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(connectionManager.status == .connected
                                      ? Color.gray.gradient
                                      : Color.orange.gradient)
                        )
                }

                statusBadge
            }
            .cardStyle()
        }
    }

    private var statusBadge: some View {
        HStack(spacing: 8) {
            Image(systemName: statusIcon)
                .foregroundStyle(statusColor)
            Text(connectionManager.status.displayText)
                .font(.subheadline)
                .foregroundStyle(statusColor)
            Spacer()
            if let last = connectionManager.lastFrameTime {
                Text("最近数据 \(last, format: .dateTime.hour().minute().second())")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - 原始数据日志（协议联调用）
    private var debugSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            stepHeader("原始数据日志（协议联调用）")

            ScrollView {
                LazyVStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(connectionManager.debugLog.enumerated().reversed()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(10)
            }
            .frame(height: 180)
            .background(Color(uiColor: .secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    // MARK: - 小组件
    private func stepHeader(_ text: String) -> some View {
        Text(text)
            .font(.headline)
            .foregroundStyle(.secondary)
    }

    private var statusIcon: String {
        switch connectionManager.status {
        case .connected:   return "checkmark.circle.fill"
        case .connecting:  return "arrow.triangle.2.circlepath"
        case .failed:      return "xmark.circle.fill"
        case .disconnected: return "circle"
        }
    }

    private var statusColor: Color {
        switch connectionManager.status {
        case .connected:   return .green
        case .connecting:  return .orange
        case .failed:      return .red
        case .disconnected: return .secondary
        }
    }
}

private extension View {
    func cardStyle() -> some View {
        self
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}
