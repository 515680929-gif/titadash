import SwiftUI

/// 胎压面板：四轮压力(bar)/温度(℃)，可被左侧双击切换显示。
/// 数据来自 TITA tpms / tpms_temp 字段，无数据显示占位。
struct TirePressureView: View {
    @Environment(VehicleState.self) private var vehicleState

    private let wheels = [
        ("左前", 0, "front.left"), ("右前", 1, "front.right"),
        ("左后", 2, "rear.left"),  ("右后", 3, "rear.right")
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("胎压 / TPMS", systemImage: "tirepressure")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(DashboardTheme.secondaryText)

            // 车身示意 + 四轮数值
            VStack(spacing: 8) {
                HStack(spacing: 12) {
                    tireCell(index: 0, name: "左前")
                    tireCell(index: 1, name: "右前")
                }
                // 车身轮廓
                RoundedRectangle(cornerRadius: 22)
                    .fill(DashboardTheme.ringTrack.opacity(0.5))
                    .frame(width: 90, height: 34)
                    .overlay(
                        Image(systemName: "car.side.fill")
                            .font(.system(size: 18))
                            .foregroundStyle(DashboardTheme.secondaryText)
                    )
                HStack(spacing: 12) {
                    tireCell(index: 2, name: "左后")
                    tireCell(index: 3, name: "右后")
                }
            }
            .frame(maxWidth: .infinity, alignment: .center)
        }
        .padding(12)
    }

    private func tireCell(index: Int, name: String) -> some View {
        let pressure = vehicleState.tirePressure[safe: index]
        let temp = vehicleState.tireTemperature[safe: index]
        let abnormal = pressure.map { $0 < 2.0 || $0 > 3.2 } ?? false
        return VStack(spacing: 2) {
            Text(name)
                .font(.system(size: 11))
                .foregroundStyle(DashboardTheme.secondaryText)
            Text(pressure.map { String(format: "%.2f", $0) } ?? "--")
                .font(DashboardTheme.monoDigit(size: 17, weight: .bold))
                .foregroundStyle(abnormal ? DashboardTheme.accentRed : DashboardTheme.primaryText)
            Text(temp.map { String(format: "%.0f℃", $0) } ?? "--℃")
                .font(.system(size: 11))
                .foregroundStyle(DashboardTheme.secondaryText)
        }
        .frame(width: 64)
        .padding(.vertical, 6)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(abnormal ? DashboardTheme.accentRed.opacity(0.12)
                               : Color(white: 0.1))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(abnormal ? DashboardTheme.accentRed.opacity(0.5)
                                 : DashboardTheme.ringTrack, lineWidth: 1)
        )
    }
}

// 安全下标，防止数组越界
private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
