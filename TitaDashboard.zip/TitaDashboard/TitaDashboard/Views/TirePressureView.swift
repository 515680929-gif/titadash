import SwiftUI

/// 胎压面板（对齐 Dashla 视频）：车辆俯视轮廓 + 四轮 psi/温度 + 中间读数。
/// 数据来自 TITA tpms / tpms_temp 字段，无数据显示占位。
struct TirePressureView: View {
    @Environment(VehicleState.self) private var vehicleState

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("胎压 / TPMS", systemImage: "tirepressure")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(DashboardTheme.secondaryText)

            ZStack {
                // 车辆俯视轮廓
                carBody
                // 四轮读数（俯视四角）
                tireCell(index: 0, name: "左前")
                    .offset(x: -58, y: -46)
                tireCell(index: 1, name: "右前")
                    .offset(x: 58, y: -46)
                tireCell(index: 2, name: "左后")
                    .offset(x: -58, y: 46)
                tireCell(index: 3, name: "右后")
                    .offset(x: 58, y: 46)
                // 中间温度
                centerReadout
            }
            .frame(maxWidth: .infinity, minHeight: 190)
        }
        .padding(12)
    }

    // 车身俯视：圆角矩形车体 + 前后挡风 + 车窗
    private var carBody: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 30)
                .fill(LinearGradient(colors: [Color(white: 0.20), Color(white: 0.12)],
                                     startPoint: .top, endPoint: .bottom))
                .frame(width: 76, height: 150)
            RoundedRectangle(cornerRadius: 30)
                .stroke(DashboardTheme.ringTrack, lineWidth: 1)
                .frame(width: 76, height: 150)
            // 前后挡风玻璃
            RoundedRectangle(cornerRadius: 8).fill(Color(white: 0.06))
                .frame(width: 56, height: 26).offset(y: -50)
            RoundedRectangle(cornerRadius: 8).fill(Color(white: 0.06))
                .frame(width: 56, height: 22).offset(y: 50)
            // 车顶天窗
            RoundedRectangle(cornerRadius: 10).fill(Color(white: 0.05))
                .frame(width: 52, height: 44)
        }
    }

    private var centerReadout: some View {
        VStack(spacing: 2) {
            let avgTemp = averageTemp
            Text(avgTemp.map { String(format: "%.0f°", $0) } ?? "--°")
                .font(DashboardTheme.monoDigit(size: 20, weight: .bold))
                .foregroundStyle(DashboardTheme.primaryText)
            Text("胎温")
                .font(.system(size: 10))
                .foregroundStyle(DashboardTheme.secondaryText)
        }
    }

    private func tireCell(index: Int, name: String) -> some View {
        let pressureBar = vehicleState.tirePressure[safe: index]
        let temp = vehicleState.tireTemperature[safe: index]
        let psi = pressureBar.map { $0 * 14.5038 }   // bar → psi
        let abnormal = pressureBar.map { $0 < 2.0 || $0 > 3.2 } ?? false
        let color: Color = abnormal ? DashboardTheme.signalRed : DashboardTheme.signalGreen
        return VStack(spacing: 1) {
            Text(psi.map { String(format: "%.0f", $0) } ?? "--")
                .font(DashboardTheme.monoDigit(size: 16, weight: .bold))
                .foregroundStyle(color)
            Text("psi")
                .font(.system(size: 9))
                .foregroundStyle(DashboardTheme.secondaryText)
            Text(temp.map { String(format: "%.0f°", $0) } ?? "--°")
                .font(.system(size: 9))
                .foregroundStyle(DashboardTheme.secondaryText)
        }
        .frame(width: 52)
        .padding(.vertical, 5)
        .background(RoundedRectangle(cornerRadius: 8)
            .fill(abnormal ? DashboardTheme.signalRed.opacity(0.12) : Color(white: 0.09)))
        .overlay(RoundedRectangle(cornerRadius: 8)
            .stroke(color.opacity(0.5), lineWidth: 1))
        .shadow(color: color.opacity(abnormal ? 0.4 : 0), radius: 6)
    }

    private var averageTemp: Double? {
        let temps = vehicleState.tireTemperature.filter { $0 > 0 }
        guard !temps.isEmpty else { return nil }
        return temps.reduce(0, +) / Double(temps.count)
    }
}

private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
