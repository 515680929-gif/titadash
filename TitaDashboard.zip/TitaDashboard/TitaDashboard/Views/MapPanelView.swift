import SwiftUI
import MapKit

/// 地图层：苹果地图（MapKit），作为仪表盘背景或独立面板。
/// 支持：跟随定位、车头朝上、按速度自动缩放、2D/3D、车标样式与锚点。
struct MapPanelView: View {
    @ObservedObject var settings: AppSettings
    let locationService: LocationService
    @Environment(VehicleState.self) private var vehicleState

    @State private var camera: MapCameraPosition = .automatic

    var body: some View {
        Map(position: $camera, interactionModes: [.pan, .zoom]) {
            // 自定义车标（替代默认蓝点）
            if let coord = locationService.coordinate {
                Annotation("", coordinate: coord) {
                    navIconView
                }
                .annotationTitles(.hidden)
            }
        }
        .mapStyle(.standard(elevation: settings.navIcon3D ? .realistic : .flat,
                            pointsOfInterest: .excludingAll))
        .mapControls { } // 隐藏默认控件，保持仪表盘干净
        .onAppear {
            locationService.start()
        }
        .onChange(of: locationService.coordinate?.latitude) { _, _ in updateCamera() }
        .onChange(of: locationService.coordinate?.longitude) { _, _ in updateCamera() }
    }

    // MARK: - 车标（叠加 TITA 实时灯光：大灯/刹车灯/转向灯/双闪）
    @ViewBuilder
    private var navIconView: some View {
        ZStack {
            // 车头方向灯光锥形（大灯开启时）
            if vehicleState.headlightsOn || vehicleState.hazardOn {
                Image(systemName: "trapezoid.and.line.horizontal.fill")
                    .font(.system(size: 30))
                    .foregroundStyle(Color.yellow.opacity(0.55))
                    .offset(y: -22)
                    .blur(radius: 1)
            }

            // 车体
            switch settings.navIcon {
            case .simple:
                Image(systemName: "location.north.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(.red)
                    .rotationEffect(.degrees(locationService.heading))
            case .realistic:
                Image(systemName: "navigation.fill")
                    .font(.system(size: 26))
                    .foregroundStyle(.white)
                    .shadow(color: .red, radius: 6)
                    .rotationEffect(.degrees(locationService.heading))
            default:
                let assetName = "car_" + settings.navIcon.rawValue
                    .lowercased().replacingOccurrences(of: " ", with: "")
                if UIImage(named: assetName) != nil {
                    Image(assetName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 44)
                        .rotationEffect(.degrees(locationService.heading))
                } else {
                    Image(systemName: "car.fill")
                        .font(.system(size: 26))
                        .foregroundStyle(.white)
                        .rotationEffect(.degrees(locationService.heading))
                }
            }

            // 刹车灯：车尾（下方）红色光点
            if vehicleState.brakeActive {
                HStack(spacing: 16) {
                    Circle().fill(Color.red).frame(width: 6, height: 6)
                    Circle().fill(Color.red).frame(width: 6, height: 6)
                }
                .offset(y: 18)
                .shadow(color: .red, radius: 5)
            }

            // 转向灯 / 双闪：左右橙色呼吸箭头
            HStack(spacing: 40) {
                Circle()
                    .fill((vehicleState.leftTurnSignal || vehicleState.hazardOn)
                          ? Color.orange : Color.clear)
                    .frame(width: 8, height: 8)
                Circle()
                    .fill((vehicleState.rightTurnSignal || vehicleState.hazardOn)
                          ? Color.orange : Color.clear)
                    .frame(width: 8, height: 8)
            }
            .offset(y: 6)
            .shadow(color: .orange, radius: 4)
        }
    }

    // MARK: - 相机跟随 + 自动缩放
    private func updateCamera() {
        guard let coord = locationService.coordinate else { return }

        // 按车速调整可视范围：速度越快看得越远（自动缩放）
        let speed = max(locationService.gpsSpeedKmh, 0)
        let distance: Double = settings.mapAutoZoom
            ? 300 + speed * 25   // 静止 300m，120km/h 约 3.3km
            : 800

        // 3D 模式带俯仰角；路口自动切 2D 由导航逻辑在接近路口时改 pitch（预留）
        let pitch: Double = settings.navIcon3D ? 55 : 0

        withAnimation(.linear(duration: 0.3)) {
            camera = .camera(MapCamera(
                centerCoordinate: coord,
                distance: distance,
                heading: locationService.heading,   // 车头朝上
                pitch: pitch
            ))
        }
    }
}
