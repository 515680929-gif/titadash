import SwiftUI
import AudioToolbox

enum AppRoute {
    case dashboard, connection, settings
}

struct RootView: View {
    @State private var route: AppRoute = .dashboard
    @Environment(VehicleState.self) private var vehicleState
    @Environment(TitaConnectionManager.self) private var connectionManager
    @StateObject private var settings = AppSettings()
    @State private var locationService = LocationService()
    @State private var nowPlaying = NowPlayingService()
    @State private var speedCamService = SpeedCameraService()
    @State private var simulator: VehicleSimulator?
    @AppStorage("simulatorMode") private var simulatorMode = false

    var body: some View {
        ZStack {
            DashboardTheme.background.ignoresSafeArea()

            switch route {
            case .dashboard:
                DashboardView(
                    settings: settings,
                    locationService: locationService,
                    nowPlaying: nowPlaying,
                    speedCamService: speedCamService,
                    onOpenSettings: { route = .settings },
                    onOpenConnection: { route = .connection }
                )
            case .connection:
                ConnectionView(onBack: { route = .dashboard })
            case .settings:
                SettingsView(settings: settings,
                             speedCamService: speedCamService,
                             onBack: { route = .dashboard })
            }
        }
        // 主题（浅色/深色/自动）
        .preferredColorScheme(colorScheme)
        .onAppear {
            UIApplication.shared.isIdleTimerDisabled = true // 屏幕常亮
            locationService.start()
            nowPlaying.lyricsBaseURL = settings.lyricsDBUrl
            if simulatorMode { startSimulator() }
        }
        .onChange(of: simulatorMode) { _, newValue in
            newValue ? startSimulator() : stopSimulator()
        }
        .onChange(of: settings.lyricsDBUrl) { _, url in
            nowPlaying.lyricsBaseURL = url
        }
        // GPS 位置 → 测速提醒（约 1Hz 检查）
        .onChange(of: locationService.coordinate?.latitude) { _, _ in checkSpeedCam() }
        .onChange(of: locationService.coordinate?.longitude) { _, _ in checkSpeedCam() }
        // 绿灯提示音（TITA 专属）：红灯/无 → 绿灯 时响一次
        .onChange(of: vehicleState.trafficLight) { old, new in
            if new == "green", old != "green", settings.greenLightChime {
                playGreenChime()
            }
        }
    }

    /// 绿灯提示音：用系统音效，按设置的延迟播报
    private func playGreenChime() {
        let delay: Double
        switch settings.greenChimeDelay {
        case .now: delay = 0
        case .s1:  delay = 1
        case .s3:  delay = 3
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            AudioServicesPlaySystemSound(1054)
        }
    }

    private var colorScheme: ColorScheme? {
        switch settings.theme {
        case .light: return .light
        case .dark:  return .dark
        case .auto:  return nil
        }
    }

    private func checkSpeedCam() {
        guard let coord = locationService.coordinate else { return }
        speedCamService.voiceVolume = Float(settings.voiceVolume)
        // 优先用发射器车速，没有时用 GPS 速度
        let speed = vehicleState.speedKmh ?? locationService.gpsSpeedKmh
        speedCamService.check(location: coord,
                              heading: locationService.heading,
                              speedKmh: speed,
                              settings: settings)
    }

    private func startSimulator() {
        let sim = simulator ?? VehicleSimulator(vehicleState: vehicleState)
        simulator = sim
        connectionManager.disconnect()
        sim.start()
    }

    private func stopSimulator() {
        simulator?.stop()
    }
}
