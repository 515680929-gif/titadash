import SwiftUI
import UniformTypeIdentifiers

/// 设置页：深色分组卡片风格，对应截图全部设置项
struct SettingsView: View {
    @ObservedObject var settings: AppSettings
    let speedCamService: SpeedCameraService
    var onBack: () -> Void

    @State private var showCamImporter = false
    @State private var camImportResult: String? = nil

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    preferenceSection
                    speedoSection
                    mapSection
                    navIconSection
                    lyricsSection
                    speedCamSection
                    unitSection
                    titaSection
                    aboutSection
                }
                .padding(16)
            }
            .background(Color.black.ignoresSafeArea())
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: onBack) { Image(systemName: "chevron.left") }
                }
            }
            .fileImporter(isPresented: $showCamImporter,
                          allowedContentTypes: [.commaSeparatedText, .plainText]) { result in
                if case .success(let url) = result,
                   url.startAccessingSecurityScopedResource(),
                   let csv = try? String(contentsOf: url, encoding: .utf8) {
                    let n = speedCamService.importCSV(csv, version: SpeedCameraService.todayVersion())
                    camImportResult = "已导入 \(n) 个测速点"
                    url.stopAccessingSecurityScopedResource()
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    // MARK: - 偏好设置
    private var preferenceSection: some View {
        SettingSection(title: "偏好设置") {
            SettingRow(icon: "circle.lefthalf.filled", title: "主题") {
                PillPicker(selection: $settings.theme) { t in Label(t.rawValue, systemImage: themeIcon(t)) }
            }
            SettingRow(icon: "textformat.size", title: "显示大小", subtitle: "放大仪表板的文字与卡片") {
                PillPicker(selection: $settings.displaySize) { Text($0.rawValue) }
            }
            SettingRow(icon: "steeringwheel", title: "驾驶侧") {
                PillPicker(selection: $settings.driverSide) { Text($0.rawValue) }
            }
            SettingRow(icon: "pip", title: "后台显示") {
                PillPicker(selection: $settings.backgroundMode) { Text($0.rawValue) }
            }
            SettingRow(icon: "rectangle.inset.filled", title: "HUD 模式") {
                HStack {
                    PillPicker(selection: $settings.hudMode) { Text($0.rawValue) }
                }
            }
            SettingRow(icon: "arrow.triangle.2.circlepath", title: "刷新模式",
                       subtitle: "仪表盘反应最灵敏，但手机会比较耗电与发烫。") {
                PillPicker(selection: $settings.refreshMode) { Text($0.rawValue) }
            }
            SettingRow(icon: "speaker.wave.2", title: "语音播报音量",
                       subtitle: "测速照相与导航语音共用") {
                HStack {
                    StepperButton(systemName: "minus") {
                        settings.voiceVolume = max(0, settings.voiceVolume - 0.05)
                    }
                    Text("\(Int(settings.voiceVolume * 100))%")
                        .font(.system(.body, design: .rounded).monospacedDigit())
                        .frame(width: 56)
                    StepperButton(systemName: "plus") {
                        settings.voiceVolume = min(1, settings.voiceVolume + 0.05)
                    }
                }
            }
        }
    }

    // MARK: - 仪表盘样式
    private var speedoSection: some View {
        SettingSection(title: "仪表盘样式") {
            SettingRow(icon: "square.on.square", title: "方向") {
                PillPicker(selection: $settings.orientation) { Text($0.rawValue) }
            }
            SettingRow(icon: "gauge.medium", title: "时速表样式", subtitle: "连点两下可以快速切换") {
                PillPicker(selection: $settings.speedoStyle) { Text($0.rawValue) }
            }
            SettingRow(icon: "paintpalette", title: "时速表颜色") {
                HStack(spacing: 12) {
                    ForEach(Gear.allCases, id: \.self) { gear in
                        VStack(spacing: 2) {
                            ColorPicker("", selection: gearColorBinding(gear), supportsOpacity: false)
                                .labelsHidden()
                                .frame(width: 34, height: 34)
                            Text(gear.rawValue).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            SettingRow(icon: "bolt", title: "电机功率样式") {
                PillPicker(selection: $settings.motorPowerStyle) { Text($0.rawValue) }
            }
            SettingRow(icon: "location", title: "实时位置", subtitle: "点一下可以快速切换") {
                PillPicker(selection: $settings.realtimePosition) { Text($0.rawValue) }
            }
            SettingRow(icon: "thermometer.medium", title: "温度显示", subtitle: "点一下可以快速切换") {
                PillPicker(selection: $settings.tempDisplay) { Text($0.rawValue) }
            }
        }
    }

    // MARK: - 地图
    private var mapSection: some View {
        SettingSection(title: "地图") {
            SettingRow(icon: "map", title: "地图") {
                HStack {
                    Toggle("", isOn: $settings.mapEnabled).labelsHidden()
                    PillPicker(selection: $settings.mapProvider) { Text($0.rawValue) }
                }
            }
            SettingRow(icon: "location.circle", title: "定位模式") {
                PillPicker(selection: $settings.locationMode) { Text($0.rawValue) }
            }
            if settings.locationMode != .phone {
                Text("使用车辆定位，易受蓝牙连接波动影响。车机 GPS 需特斯拉 BLE 协议支持（开发中）。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 4)
            }
            SettingToggleRow(icon: "arrow.up.left.and.arrow.down.right", title: "自动缩放",
                             isOn: $settings.mapAutoZoom)
            SettingToggleRow(icon: "camera.metering.multispot", title: "路口自动切换 2D",
                             subtitle: "转弯前切俯视，路口更好判断",
                             isOn: $settings.junction2D)
            SettingToggleRow(icon: "person.wave.2", title: "导航语音",
                             subtitle: "播报接下来的转弯",
                             isOn: $settings.navVoiceEnabled)
        }
    }

    // MARK: - 导航图标
    private var navIconSection: some View {
        SettingSection(title: "导航图标") {
            HStack {
                Spacer()
                Picker("", selection: $settings.navIcon3D) {
                    Text("2D").tag(false)
                    Text("3D").tag(true)
                }
                .pickerStyle(.segmented)
                .frame(width: 120)
            }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 10) {
                ForEach(AppSettings.NavIcon.allCases, id: \.self) { icon in
                    Button { settings.navIcon = icon } label: {
                        VStack(spacing: 6) {
                            Image(systemName: iconSymbol(icon))
                                .font(.system(size: 28))
                                .foregroundStyle(settings.navIcon == icon ? .white : .secondary)
                                .frame(height: 36)
                            Text(icon.rawValue)
                                .font(.caption2)
                                .foregroundStyle(settings.navIcon == icon ? .white : .secondary)
                                .lineLimit(1)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color(white: 0.12))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(settings.navIcon == icon
                                                ? Color.indigo : Color.clear, lineWidth: 2)
                                )
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
            SettingRow(icon: "mappin", title: "车标位置") {
                PillPicker(selection: $settings.iconAnchor) { Text($0.rawValue) }
            }
        }
    }

    // MARK: - 歌词播放器
    private var lyricsSection: some View {
        SettingSection(title: "歌词播放器") {
            SettingRow(icon: "music.note.list", title: "歌词数据库") {
                PillPicker(selection: $settings.lyricsSource) { Text($0.rawValue) }
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("LRCLIB 是免费开源歌词数据库。歌词与数据库内容版权归原作者所有，本 App 仅提供歌词浏览功能，不提供歌词内容。请自行确认使用方式符合相关授权与所在地法规。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Toggle("我已详细阅读并同意", isOn: $settings.lyricsAgreed)
                    .font(.subheadline)
            }
            .padding(.horizontal, 4)
            SettingRow(icon: "link", title: "数据库网址") {
                HStack {
                    TextField("https://lrclib.net", text: $settings.lyricsDBUrl)
                        .keyboardType(.URL)
                        .autocapitalization(.none)
                        .font(.system(.subheadline, design: .monospaced))
                        .padding(8)
                        .background(RoundedRectangle(cornerRadius: 8).fill(Color(white: 0.12)))
                    if settings.lyricsDBUrl.hasPrefix("https://") {
                        Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                    }
                }
            }
        }
    }

    // MARK: - 测速照相
    private var speedCamSection: some View {
        SettingSection(title: "测速照相") {
            SettingRow(icon: "bell.badge", title: "测速提醒") {
                HStack(spacing: 2) {
                    ForEach([true, false], id: \.self) { on in
                        Button { settings.speedCamEnabled = on } label: {
                            Text(on ? "开启" : "关闭")
                                .font(.subheadline.weight(settings.speedCamEnabled == on ? .semibold : .regular))
                                .foregroundStyle(settings.speedCamEnabled == on ? .white : .secondary)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 7)
                                .background(Capsule().fill(settings.speedCamEnabled == on ? Color.indigo : Color.clear))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(3)
                .background(Capsule().fill(Color(white: 0.15)))
            }
            Toggle("提示卡片", isOn: $settings.speedCamCard)
            Toggle("警示音", isOn: $settings.speedCamSound)
            Text("音量请至「偏好设置」调整。").font(.caption).foregroundStyle(.secondary)
            SettingRow(icon: "person.2.wave.2", title: "通过提示") {
                PillPicker(selection: $settings.speedCamPassNotice) { Text($0.rawValue) }
            }
            VStack(alignment: .leading, spacing: 6) {
                Label("类型", systemImage: "camera")
                    .font(.subheadline)
                HStack(spacing: 16) {
                    Toggle("固定测速", isOn: $settings.speedCamFixed)
                    Toggle("移动测速", isOn: $settings.speedCamMobile)
                }
                .font(.subheadline)
            }
            SettingRow(icon: "clock", title: "提醒时机") {
                PillPicker(selection: $settings.speedCamTiming) { Text($0.rawValue) }
            }
            thresholdRow(title: "超过限速：",
                         mode: $settings.speedCamThresholdMode,
                         value: $settings.speedCamThresholdValue)
            VStack(alignment: .leading, spacing: 6) {
                Label("其他类型", systemImage: "flag")
                    .font(.subheadline)
                Text("科技执法与区间测速不受上方时机影响")
                    .font(.caption).foregroundStyle(.secondary)
                HStack(spacing: 16) {
                    Toggle("科技执法", isOn: $settings.speedCamTech)
                    Toggle("区间测速 (Beta)", isOn: $settings.speedCamSection)
                }
                .font(.subheadline)
            }
            // 图资
            HStack {
                Label("测速图资", systemImage: "camera.on.rectangle")
                    .font(.subheadline)
                Spacer()
                Toggle("自动更新", isOn: $settings.speedCamAutoUpdate)
                    .labelsHidden()
            }
            HStack {
                Text("版本: \(speedCamService.dataVersion)")
                    .font(.caption).foregroundStyle(.secondary)
                Spacer()
                Button("导入 CSV") { showCamImporter = true }
                    .font(.subheadline)
            }
            if let msg = camImportResult {
                Text(msg).font(.caption).foregroundStyle(.green)
            }
        }
    }

    // MARK: - 单位格式
    private var unitSection: some View {
        SettingSection(title: "单位格式") {
            SettingRow(icon: "speedometer", title: "时速") {
                PillPicker(selection: $settings.speedUnit) { Text($0.rawValue) }
            }
        }
    }

    // MARK: - TITA 专属
    private var titaSection: some View {
        SettingSection(title: "TITA（需搭配发射器）") {
            SettingRow(icon: "eye", title: "盲点警示灯号") {
                PillPicker(selection: $settings.blindSpotStyle) { Text($0.rawValue) }
            }
            SettingRow(icon: "clock", title: "提醒时机") {
                PillPicker(selection: $settings.blindSpotTiming) { Text($0.rawValue) }
            }
            SettingRow(icon: "arrow.triangle.branch", title: "转向灯号", subtitle: "点一下可以快速切换") {
                PillPicker(selection: $settings.signalStyle) { Text($0.rawValue) }
            }
            SettingToggleRow(icon: "person.and.background.dotted", title: "安全带灯号",
                             isOn: $settings.seatbeltWarning)
            SettingToggleRow(icon: "brakesignal", title: "刹车灯号",
                             isOn: $settings.brakeLight)
            SettingToggleRow(icon: "bell", title: "超速警示",
                             isOn: $settings.overspeedWarning)
            thresholdRow(title: "超过限速：",
                         mode: $settings.overspeedMode,
                         value: $settings.overspeedValue)
            SettingRow(icon: "trafficlight", title: "红绿灯显示") {
                PillPicker(selection: $settings.trafficLightMode) { Text($0.rawValue) }
            }
            HStack {
                Toggle("绿灯提示音", isOn: $settings.greenLightChime)
                    .font(.subheadline)
                Spacer()
                PillPicker(selection: $settings.greenChimeDelay) { Text($0.rawValue) }
            }
        }
    }

    // MARK: - 关于
    private var aboutSection: some View {
        SettingSection(title: "关于") {
            VStack(alignment: .leading, spacing: 6) {
                Text("TitaDashboard 1.0")
                    .font(.subheadline)
                Text("通过 TITA 发射器读取车辆数据，仅读取不写入。本 App 与 TITA / Tesla 官方无关。地图数据 © Apple Maps（高德）。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 4)
        }
    }

    // MARK: - 通用组件

    private func thresholdRow(title: String,
                              mode: Binding<AppSettings.ThresholdMode>,
                              value: Binding<Double>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label(title, systemImage: "gauge.with.dots.needle.67percent")
                    .font(.subheadline)
                Spacer()
                PillPicker(selection: mode) { Text($0.rawValue) }
            }
            HStack {
                Spacer()
                StepperButton(systemName: "minus") { value.wrappedValue = max(0, value.wrappedValue - 1) }
                Text(mode.wrappedValue == .fixed
                     ? "\(Int(value.wrappedValue)) km/h"
                     : "\(Int(value.wrappedValue)) %")
                    .font(.system(.body, design: .rounded).monospacedDigit())
                    .frame(width: 90)
                StepperButton(systemName: "plus") { value.wrappedValue += 1 }
            }
        }
    }

    private func gearColorBinding(_ gear: Gear) -> Binding<Color> {
        Binding(
            get: { settings.gearColors[gear] ?? .white },
            set: { settings.gearColors[gear] = $0 }
        )
    }

    private func themeIcon(_ t: AppSettings.AppTheme) -> String {
        switch t {
        case .light: return "sun.max"
        case .dark:  return "moon"
        case .auto:  return "circle.lefthalf.filled"
        }
    }

    private func iconSymbol(_ icon: AppSettings.NavIcon) -> String {
        switch icon {
        case .simple:    return "location.north.fill"
        case .realistic: return "navigation.fill"
        default:         return "car.fill"
        }
    }
}

// MARK: - 复用控件

/// 分组卡片容器
struct SettingSection<Content: View>: View {
    let title: String
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(.leading, 4)
            VStack(alignment: .leading, spacing: 16) {
                content
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 16).fill(Color(white: 0.09)))
        }
    }
}

/// 图标 + 标题(+副标题) + 右侧控件
struct SettingRow<Control: View>: View {
    let icon: String
    let title: String
    var subtitle: String? = nil
    @ViewBuilder var control: Control

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: icon)
                .frame(width: 24)
                .foregroundStyle(.secondary)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline)
                if let subtitle {
                    Text(subtitle).font(.caption).foregroundStyle(.secondary)
                }
            }
            Spacer()
            control
        }
    }
}

/// 开关行
struct SettingToggleRow: View {
    let icon: String
    let title: String
    var subtitle: String? = nil
    @Binding var isOn: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).frame(width: 24).foregroundStyle(.secondary)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline)
                if let subtitle {
                    Text(subtitle).font(.caption).foregroundStyle(.secondary)
                }
            }
            Spacer()
            Toggle("", isOn: $isOn).labelsHidden()
        }
    }
}

/// 胶囊分段选择器（对应截图中的紫色分段按钮）
struct PillPicker<Value: Hashable & CaseIterable, Label: View>: View {
    @Binding var selection: Value
    @ViewBuilder var label: (Value) -> Label

    var body: some View {
        HStack(spacing: 2) {
            ForEach(Array(Value.allCases), id: \.self) { value in
                Button { selection = value } label: {
                    label(value)
                        .font(.subheadline.weight(selection == value ? .semibold : .regular))
                        .foregroundStyle(selection == value ? .white : .secondary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(
                            Capsule().fill(selection == value
                                           ? Color.indigo : Color.clear)
                        )
                }
                .buttonStyle(.plain)
            }
        }
        .padding(3)
        .background(Capsule().fill(Color(white: 0.15)))
    }
}

/// 圆形加减按钮
struct StepperButton: View {
    let systemName: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 34, height: 34)
                .background(Circle().fill(Color.indigo))
        }
        .buttonStyle(.plain)
    }
}
