import SwiftUI

/// 中央大圆环时速表（环绕式信号灯布局，还原参考图）：
/// 顶部 AP 方向盘（蓝底）/ 左上限速牌（欧式白底红环黑字）/ 右上红绿灯 /
/// 右 AutoHold (H) / 右下尾门 / 底部车门 / 左下前备箱 / 最左 ESP。
/// 每个信号灯带半透明「灯座」，点亮时彩色发光，未点亮时暗灰轮廓。
struct SpeedDialView: View {
    @Environment(VehicleState.self) private var vehicleState
    @ObservedObject var settings: AppSettings

    private let maxSpeed: Double = 200
    @State private var flashOn = false

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height) * 0.94
            let u = size / 320 // 基准比例：以 320 直径设计各元素尺寸

            ZStack {
                // 外环（底）
                Circle()
                    .stroke(DashboardTheme.ringTrack, lineWidth: 2)

                // 刹车灯：顶部红色弧（TITA 专属）
                if settings.brakeLight, vehicleState.brakeActive {
                    Circle()
                        .trim(from: 0.43, to: 0.57)
                        .stroke(Color.red, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .shadow(color: .red, radius: 8)
                }

                // 转向灯弧形（TITA 专属）
                if settings.signalStyle == .arc {
                    if vehicleState.leftTurnSignal {
                        signalArc(trim: 0.72...0.92)
                    }
                    if vehicleState.rightTurnSignal {
                        signalArc(trim: 0.08...0.28)
                    }
                }

                // 速度进度弧
                if let speed = vehicleState.speedKmh, speed > 0 {
                    Circle()
                        .trim(from: 0, to: min(speed / maxSpeed, 1.0) * 0.75)
                        .stroke(speedColor,
                                style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .rotationEffect(.degrees(135))
                        .animation(.linear(duration: 0.15), value: vehicleState.speedKmh)
                }

                // ===== 中心内容：PRND + 横线时速 + km/h =====
                VStack(spacing: 0) {
                    gearRow(u: u)
                        .padding(.top, 34 * u)
                    Spacer()
                    speedValue(u: u)
                    Text(settings.speedUnit.rawValue)
                        .font(.system(size: 17 * u, weight: .medium))
                        .foregroundStyle(DashboardTheme.secondaryText)
                        .padding(.top, 2)
                    Spacer()
                }
                .frame(width: size * 0.55)

                // ===== 环绕信号灯 =====
                // 顶部：AP 状态（蓝底白方向盘）
                apIndicator(u: u)
                    .offset(y: -size * 0.40)

                // 左上：车机导航限速（欧式限速牌）
                speedLimitBadge(u: u)
                    .offset(x: -size * 0.33, y: -size * 0.21)

                // 右上：红绿灯
                trafficLights(u: u)
                    .offset(x: size * 0.33, y: -size * 0.20)

                // 最右：AutoHold
                autoHoldIndicator(u: u)
                    .offset(x: size * 0.42)

                // 右下：尾门未关
                lamp(systemName: "car.side.rear.open",
                     color: DashboardTheme.accentRed,
                     active: vehicleState.trunkOpen, u: u)
                    .offset(x: size * 0.30, y: size * 0.30)

                // 底部：车门未关
                lamp(systemName: "car.side.front.open",
                     color: DashboardTheme.accentRed,
                     active: vehicleState.doorAjar, u: u)
                    .offset(y: size * 0.42)

                // 左下：前备箱未关
                lamp(systemName: "car.side.front.open",
                     color: DashboardTheme.accentRed,
                     active: vehicleState.frunkOpen, u: u)
                    .rotationEffect(.degrees(180))
                    .offset(x: -size * 0.30, y: size * 0.30)

                // 最左：ESP 报警
                lamp(systemName: "car.side",
                     color: DashboardTheme.accentOrange,
                     active: vehicleState.espActive, u: u)
                    .offset(x: -size * 0.42)
            }
            .frame(width: size, height: size)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
        .onAppear {
            // 超速/呼吸闪烁定时器
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
                flashOn.toggle()
            }
        }
    }

    // MARK: - 中心档位
    private func gearRow(u: CGFloat) -> some View {
        HStack(spacing: 18 * u) {
            ForEach(Gear.allCases, id: \.self) { gear in
                Text(gear.rawValue)
                    .font(.system(size: 24 * u, weight: .bold, design: .rounded))
                    .foregroundStyle(
                        vehicleState.gear == gear
                            ? (settings.gearColors[gear] ?? DashboardTheme.gearActive)
                            : DashboardTheme.gearInactive
                    )
            }
        }
    }

    /// 中心速度：有数据显示数字，无数据显示白色横线（还原参考图占位样式）
    @ViewBuilder
    private func speedValue(u: CGFloat) -> some View {
        if let _ = vehicleState.speedKmh {
            Text(speedText)
                .font(DashboardTheme.monoDigit(size: 58 * u, weight: .bold))
                .foregroundStyle(overspeed && flashOn
                                 ? DashboardTheme.accentRed
                                 : DashboardTheme.primaryText)
                .contentTransition(.numericText())
                .animation(.linear(duration: 0.1), value: vehicleState.speedKmh)
        } else {
            RoundedRectangle(cornerRadius: 8 * u)
                .fill(DashboardTheme.primaryText)
                .frame(width: 96 * u, height: 10 * u)
        }
    }

    // MARK: - 通用信号灯（带灯座）
    private func lamp(systemName: String, color: Color,
                      active: Bool, u: CGFloat) -> some View {
        ZStack {
            // 灯座：半透明深色圆底
            Circle()
                .fill(Color.white.opacity(active ? 0.14 : 0.05))
            Circle()
                .stroke(active ? color : DashboardTheme.gearInactive.opacity(0.45),
                        lineWidth: active ? 2 : 1.5)
            Image(systemName: systemName)
                .font(.system(size: 20 * u, weight: .semibold))
                .foregroundStyle(active ? color : DashboardTheme.gearInactive.opacity(0.40))
        }
        .frame(width: 36 * u, height: 36 * u)
        .shadow(color: active ? color : .clear, radius: active ? 8 : 0)
        .animation(.easeInOut(duration: 0.25), value: active)
    }

    // 顶部 AP 方向盘（蓝底白标）
    private func apIndicator(u: CGFloat) -> some View {
        let active = vehicleState.autopilotActive
        return ZStack {
            Circle()
                .fill(active ? Color.blue : Color.blue.opacity(0.12))
            Circle()
                .stroke(active ? Color.blue : DashboardTheme.gearInactive.opacity(0.45),
                        lineWidth: active ? 2 : 1.5)
            Image(systemName: "steeringwheel")
                .font(.system(size: 20 * u, weight: .semibold))
                .foregroundStyle(active ? Color.white : DashboardTheme.gearInactive.opacity(0.40))
        }
        .frame(width: 36 * u, height: 36 * u)
        .shadow(color: active ? .blue : .clear, radius: active ? 8 : 0)
        .animation(.easeInOut(duration: 0.25), value: active)
    }

    // 最右 AutoHold（H）
    private func autoHoldIndicator(u: CGFloat) -> some View {
        let active = vehicleState.autoholdActive
        return ZStack {
            Circle()
                .fill(Color.white.opacity(active ? 0.14 : 0.05))
            Circle()
                .stroke(active ? Color.white : DashboardTheme.gearInactive.opacity(0.45),
                        lineWidth: active ? 2 : 1.5)
            Text("(H)")
                .font(.system(size: 16 * u, weight: .semibold, design: .rounded))
                .foregroundStyle(active ? DashboardTheme.primaryText
                                 : DashboardTheme.gearInactive.opacity(0.40))
        }
        .frame(width: 36 * u, height: 36 * u)
        .shadow(color: active ? Color.white.opacity(0.6) : .clear, radius: active ? 6 : 0)
        .animation(.easeInOut(duration: 0.25), value: active)
    }

    // 右上 红绿灯：红黄绿三灯竖排
    private func trafficLights(u: CGFloat) -> some View {
        VStack(spacing: 3 * u) {
            trafficDot(color: .red, on: vehicleState.trafficLight == "red", u: u)
            trafficDot(color: .yellow, on: vehicleState.trafficLight == "yellow", u: u)
            trafficDot(color: .green, on: vehicleState.trafficLight == "green", u: u)
        }
    }

    private func trafficDot(color: Color, on: Bool, u: CGFloat) -> some View {
        Circle()
            .fill(on ? color : color.opacity(0.22))
            .frame(width: 9 * u, height: 9 * u)
            .shadow(color: on ? color : .clear, radius: on ? 5 : 0)
            .animation(.easeInOut(duration: 0.2), value: on)
    }

    // 左上 限速牌：欧式白底 + 红粗外环 + 黑数字
    private func speedLimitBadge(u: CGFloat) -> some View {
        ZStack {
            if let limit = vehicleState.speedLimitKmh {
                Circle()
                    .fill(Color.white)
                Circle()
                    .stroke(Color.red, lineWidth: 4 * u)
                    .padding(1 * u)
                Text("\(limit)")
                    .font(DashboardTheme.monoDigit(size: 16 * u, weight: .heavy))
                    .foregroundStyle(Color.black)
            } else {
                // 占位：暗灰细环
                Circle()
                    .stroke(DashboardTheme.ringTrack, lineWidth: 1.5)
                    .opacity(0.6)
            }
        }
        .frame(width: 34 * u, height: 34 * u)
    }

    private func signalArc(trim: ClosedRange<Double>) -> some View {
        Circle()
            .trim(from: trim.lowerBound, to: trim.upperBound)
            .stroke(DashboardTheme.accentGreen,
                    style: StrokeStyle(lineWidth: 5, lineCap: .round))
            .rotationEffect(.degrees(-90))
            .opacity(flashOn ? 1 : 0.15)
            .animation(.easeInOut(duration: 0.4), value: flashOn)
    }

    // MARK: - 计算属性
    private var overspeed: Bool {
        settings.overspeedWarning &&
        vehicleState.isOverspeed(mode: settings.overspeedMode, value: settings.overspeedValue)
    }

    private var speedText: String {
        guard let s = vehicleState.speedKmh else { return "—" }
        switch settings.speedUnit {
        case .kmh: return String(format: "%.0f", s)
        case .mph: return String(format: "%.0f", s * 0.621371)
        }
    }

    private var speedColor: Color {
        guard let s = vehicleState.speedKmh else { return .clear }
        switch s {
        case ..<60:   return DashboardTheme.accentGreen
        case ..<120:  return DashboardTheme.accentOrange
        default:      return DashboardTheme.accentRed
        }
    }
}
