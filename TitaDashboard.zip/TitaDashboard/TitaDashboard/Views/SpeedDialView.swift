import SwiftUI

/// 中央大圆环时速表（对齐 Dashla 真车仪表逻辑）：
/// - 彩虹速度弧（绿→黄→橙→红）随速度填充，底部留缺口；
/// - PRND 小号灰字、当前档高亮，不放大；
/// - 左右绿色箭头转向灯（Dashla arrowactive/dim 两态）在盘外上方闪烁；
/// - 8 个环绕信号灯平时隐藏，上电/挂挡时顺时针依次点亮约 2 秒自检后熄灭；
/// - 自检后仅按条件常亮，P 档全灭。
/// 顺时针灯位：0 顶(AP) → 1 右上(红绿灯) → 2 右(HOLD) → 3 右下(尾门) →
/// 4 底(车门) → 5 左下(前备箱) → 6 左(ESP) → 7 左上(限速牌)。
struct SpeedDialView: View {
    @Environment(VehicleState.self) private var vehicleState
    @ObservedObject var settings: AppSettings

    private let maxSpeed: Double = 200
    @State private var flashOn = false

    @State private var selfLit = 0
    @State private var selfRunning = false
    private let lampCount = 8

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height) * 0.94
            let u = size / 320

            ZStack {
                // 盘内深色玻璃底
                Circle()
                    .fill(
                        RadialGradient(
                            gradient: Gradient(colors: [Color(white: 0.10), Color.black]),
                            center: .center, startRadius: 0,
                            endRadius: size * 0.5)
                    )

                // 外环底线
                Circle()
                    .stroke(Color(white: 0.16), lineWidth: 2)

                // 速度弧轨道（270°，底部缺口）
                speedArcTrack(u: u)

                // 彩虹速度进度弧
                if let speed = vehicleState.speedKmh, speed > 0 {
                    Circle()
                        .trim(from: 0, to: min(speed / maxSpeed, 1.0) * 0.75)
                        .stroke(DashboardTheme.speedRainbow,
                                style: StrokeStyle(lineWidth: 6 * u, lineCap: .round))
                        .rotationEffect(.degrees(135))
                        .shadow(color: speedGlow, radius: 6 * u)
                        .animation(.linear(duration: 0.15), value: vehicleState.speedKmh)
                }

                // 刹车灯：顶部红色弧
                if settings.brakeLight, vehicleState.brakeActive {
                    Circle()
                        .trim(from: 0.44, to: 0.56)
                        .stroke(DashboardTheme.signalRed,
                                style: StrokeStyle(lineWidth: 7 * u, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .shadow(color: DashboardTheme.signalRed, radius: 10 * u)
                }

                // ===== 中心内容 =====
                VStack(spacing: 0) {
                    gearRow(u: u)
                        .padding(.top, 40 * u)
                    Spacer()
                    speedValue(u: u)
                    Text(settings.speedUnit.rawValue)
                        .font(.system(size: 15 * u, weight: .medium))
                        .foregroundStyle(DashboardTheme.secondaryText)
                        .padding(.top, 1)
                    Spacer()
                }
                .frame(width: size * 0.56)

                // ===== 环绕信号灯 =====
                apIndicator(on: lampOn(0), u: u)
                    .offset(y: -size * 0.40)
                trafficLights(on: lampOn(1), u: u)
                    .offset(x: size * 0.33, y: -size * 0.21)
                holdIndicator(on: lampOn(2), u: u)
                    .offset(x: size * 0.43)
                symbolLamp("car.side.rear.open", color: DashboardTheme.signalRed,
                           on: lampOn(3), u: u)
                    .offset(x: size * 0.30, y: size * 0.30)
                symbolLamp("car.side.front.open", color: DashboardTheme.signalRed,
                           on: lampOn(4), u: u)
                    .offset(y: size * 0.43)
                symbolLamp("car.side.front.open", color: DashboardTheme.signalRed,
                           on: lampOn(5), u: u)
                    .rotationEffect(.degrees(180))
                    .offset(x: -size * 0.30, y: size * 0.30)
                espIndicator(on: lampOn(6), u: u)
                    .offset(x: -size * 0.43)
                speedLimitBadge(on: lampOn(7), u: u)
                    .offset(x: -size * 0.33, y: -size * 0.21)

                // ===== 左右绿色箭头转向灯（Dashla 标志性）=====
                turnArrow(direction: .left, on: vehicleState.leftTurnSignal, u: u)
                    .offset(x: -size * 0.30, y: -size * 0.33)
                turnArrow(direction: .right, on: vehicleState.rightTurnSignal, u: u)
                    .offset(x: size * 0.30, y: -size * 0.33)
            }
            .frame(width: size, height: size)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
        .onAppear {
            startTimer()
            runSelfTest()
        }
        .onChange(of: vehicleState.gear) { old, new in
            if old == .park && new != .park { runSelfTest() }
        }
    }

    // MARK: - 自检逻辑（顺时针约 2 秒）
    private func runSelfTest() {
        selfRunning = true
        selfLit = 0
        Task { @MainActor in
            for i in 1...lampCount {
                try? await Task.sleep(for: .milliseconds(220))
                selfLit = i
            }
            try? await Task.sleep(for: .milliseconds(360))
            selfRunning = false
            selfLit = 0
        }
    }

    private func lampOn(_ index: Int) -> Bool {
        if selfRunning { return index < selfLit }
        if vehicleState.gear == .park { return false }
        return conditionOn(index)
    }

    private func conditionOn(_ index: Int) -> Bool {
        switch index {
        case 0: return vehicleState.autopilotActive
        case 1: return vehicleState.trafficLight != nil
        case 2: return vehicleState.autoholdActive
        case 3: return vehicleState.trunkOpen
        case 4: return vehicleState.doorAjar
        case 5: return vehicleState.frunkOpen
        case 6: return vehicleState.espActive
        case 7: return vehicleState.speedLimitKmh != nil
        default: return false
        }
    }

    private func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            flashOn.toggle()
        }
    }

    // MARK: - 速度弧轨道
    private func speedArcTrack(u: CGFloat) -> some View {
        Circle()
            .trim(from: 0, to: 0.75)
            .stroke(Color(white: 0.14),
                    style: StrokeStyle(lineWidth: 6 * u, lineCap: .round))
            .rotationEffect(.degrees(135))
    }

    // MARK: - 中心档位（小号灰字，当前高亮不放大）
    private func gearRow(u: CGFloat) -> some View {
        HStack(spacing: 14 * u) {
            ForEach(Gear.allCases, id: \.self) { gear in
                Text(gear.rawValue)
                    .font(.system(size: 16 * u, weight: .bold, design: .rounded))
                    .foregroundStyle(
                        vehicleState.gear == gear
                            ? (settings.gearColors[gear] ?? DashboardTheme.gearActive)
                            : DashboardTheme.gearInactive
                    )
            }
        }
    }

    @ViewBuilder
    private func speedValue(u: CGFloat) -> some View {
        if let _ = vehicleState.speedKmh {
            Text(speedText)
                .font(DashboardTheme.monoDigit(size: 62 * u, weight: .bold))
                .foregroundStyle(overspeed && flashOn
                                 ? DashboardTheme.signalRed
                                 : DashboardTheme.primaryText)
                .contentTransition(.numericText())
                .animation(.linear(duration: 0.1), value: vehicleState.speedKmh)
        } else {
            RoundedRectangle(cornerRadius: 8 * u)
                .fill(DashboardTheme.primaryText)
                .frame(width: 96 * u, height: 10 * u)
        }
    }

    // MARK: - 通用信号灯（统一玻璃底座 + 发光）
    private func symbolLamp(_ name: String, color: Color,
                            on: Bool, u: CGFloat) -> some View {
        ZStack {
            Circle().fill(Color(white: 0.10))
            Circle().stroke(color.opacity(on ? 0.95 : 0.5), lineWidth: 2 * u)
            Image(systemName: name)
                .font(.system(size: 19 * u, weight: .semibold))
                .foregroundStyle(color)
        }
        .frame(width: 36 * u, height: 36 * u)
        .shadow(color: color.opacity(on ? 0.9 : 0), radius: on ? 10 * u : 0)
        .opacity(on ? 1 : 0)
        .animation(.easeInOut(duration: 0.22), value: on)
    }

    // 顶部 AP 方向盘（蓝底白标）
    private func apIndicator(on: Bool, u: CGFloat) -> some View {
        let base = DashboardTheme.signalBlue
        return ZStack {
            Circle().fill(base)
            Image(systemName: "steeringwheel")
                .font(.system(size: 20 * u, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: 36 * u, height: 36 * u)
        .shadow(color: base.opacity(on ? 0.9 : 0), radius: on ? 10 * u : 0)
        .opacity(on ? 1 : 0)
        .animation(.easeInOut(duration: 0.22), value: on)
    }

    // 右 AutoHold（(H) 白环）
    private func holdIndicator(on: Bool, u: CGFloat) -> some View {
        ZStack {
            Circle().fill(Color(white: 0.10))
            Circle().stroke(Color.white, lineWidth: 2 * u)
            Text("(H)")
                .font(.system(size: 15 * u, weight: .semibold, design: .rounded))
                .foregroundStyle(.white)
        }
        .frame(width: 36 * u, height: 36 * u)
        .shadow(color: .white.opacity(on ? 0.7 : 0), radius: on ? 8 * u : 0)
        .opacity(on ? 1 : 0)
        .animation(.easeInOut(duration: 0.22), value: on)
    }

    // 左 ESP（车侧滑 + 波纹）
    private func espIndicator(on: Bool, u: CGFloat) -> some View {
        ZStack {
            Circle().fill(Color(white: 0.10))
            Circle().stroke(DashboardTheme.accentOrange.opacity(on ? 0.95 : 0.5),
                            lineWidth: 2 * u)
            Image(systemName: "car.side")
                .font(.system(size: 19 * u, weight: .semibold))
                .foregroundStyle(DashboardTheme.accentOrange)
        }
        .frame(width: 36 * u, height: 36 * u)
        .shadow(color: DashboardTheme.accentOrange.opacity(on ? 0.9 : 0),
                radius: on ? 10 * u : 0)
        .opacity(on ? 1 : 0)
        .animation(.easeInOut(duration: 0.22), value: on)
    }

    // 右上 红绿灯：黑底竖排三灯
    private func trafficLights(on: Bool, u: CGFloat) -> some View {
        let state = vehicleState.trafficLight
        return VStack(spacing: 4 * u) {
            trafficDot(color: .red,    lit: on && (state == nil || state == "red"),    u: u)
            trafficDot(color: .yellow, lit: on && (state == nil || state == "yellow"), u: u)
            trafficDot(color: .green,  lit: on && (state == nil || state == "green"),  u: u)
        }
        .padding(.vertical, 5 * u).padding(.horizontal, 4 * u)
        .background(RoundedRectangle(cornerRadius: 8 * u).fill(Color(white: 0.08)))
        .opacity(on ? 1 : 0)
        .animation(.easeInOut(duration: 0.22), value: on)
    }

    private func trafficDot(color: Color, lit: Bool, u: CGFloat) -> some View {
        Circle()
            .fill(lit ? color : color.opacity(0.20))
            .frame(width: 10 * u, height: 10 * u)
            .shadow(color: lit ? color : .clear, radius: lit ? 6 * u : 0)
            .animation(.easeInOut(duration: 0.2), value: lit)
    }

    // 左上 限速牌：欧式白底 + 红粗环 + 黑字
    private func speedLimitBadge(on: Bool, u: CGFloat) -> some View {
        ZStack {
            Circle().fill(Color.white)
            Circle().stroke(Color.red, lineWidth: 4 * u).padding(1 * u)
            Text(vehicleState.speedLimitKmh.map(String.init) ?? "--")
                .font(DashboardTheme.monoDigit(size: 15 * u, weight: .heavy))
                .foregroundStyle(Color.black)
        }
        .frame(width: 36 * u, height: 36 * u)
        .shadow(color: .red.opacity(on ? 0.5 : 0), radius: on ? 8 * u : 0)
        .opacity(on ? 1 : 0)
        .animation(.easeInOut(duration: 0.22), value: on)
    }

    // MARK: - 转向箭头（绿色，左右闪烁）
    private enum TurnDir { case left, right }
    private func turnArrow(direction: TurnDir, on: Bool, u: CGFloat) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7 * u)
                .fill(Color(white: 0.08))
            Image(systemName: direction == .left
                  ? "arrowtriangle.left.fill" : "arrowtriangle.right.fill")
                .font(.system(size: 18 * u, weight: .bold))
                .foregroundStyle(DashboardTheme.signalGreen)
        }
        .frame(width: 38 * u, height: 28 * u)
        .shadow(color: DashboardTheme.signalGreen.opacity(on ? 0.9 : 0),
                radius: on ? 10 * u : 0)
        .opacity(on ? (flashOn ? 1 : 0.35) : 0)
        .animation(.easeInOut(duration: 0.25), value: on)
    }

    // MARK: - 计算属性
    private var overspeed: Bool {
        settings.overspeedWarning &&
        vehicleState.isOverspeed(mode: settings.overspeedMode, value: settings.overspeedValue)
    }

    private var speedText: String {
        guard let s = vehicleState.speedKmh else { return "—" }
        switch settings.speedUnit {
        case .kmh: return String(format: "%.0f", s)
        case .mph: return String(format: "%.0f", s * 0.621371)
        }
    }

    private var speedGlow: Color {
        guard let s = vehicleState.speedKmh else { return .clear }
        return s < 60 ? DashboardTheme.accentGreen
             : s < 120 ? DashboardTheme.accentOrange
             : DashboardTheme.signalRed
    }
}
