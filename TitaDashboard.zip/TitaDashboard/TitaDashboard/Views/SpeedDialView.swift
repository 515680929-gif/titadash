import SwiftUI

/// 中央大圆环时速表：外环随速度点亮、PRND 档位、速度大字、km/h
/// TITA 增强：刹车灯弧形、盲点警示、限速牌、超速闪烁、红绿灯
struct SpeedDialView: View {
    @Environment(VehicleState.self) private var vehicleState
    @ObservedObject var settings: AppSettings

    private let maxSpeed: Double = 200
    /// 超速闪烁动画用
    @State private var flashOn = false

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height) * 0.92

            ZStack {
                // 底环
                Circle()
                    .stroke(DashboardTheme.ringTrack, lineWidth: 3)

                // 刹车灯：圆环顶部红色弧（TITA 专属，对应 Dashla「刹车灯号」）
                if settings.brakeLight, vehicleState.brakeActive {
                    Circle()
                        .trim(from: 0.42, to: 0.58)
                        .stroke(Color.red, style: StrokeStyle(lineWidth: 7, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .shadow(color: .red, radius: 8)
                }

                // 转向灯：弧形模式（TITA 专属，对应「转向灯号-弧形」）
                if settings.signalStyle == .arc {
                    if vehicleState.leftTurnSignal {
                        signalArc(trim: 0.75...0.95)
                    }
                    if vehicleState.rightTurnSignal {
                        signalArc(trim: 0.05...0.25)
                    }
                }

                // 速度进度弧
                if let speed = vehicleState.speedKmh, speed > 0 {
                    Circle()
                        .trim(from: 0, to: min(speed / maxSpeed, 1.0) * 0.75)
                        .stroke(speedColor,
                                style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .rotationEffect(.degrees(135))
                        .animation(.linear(duration: 0.15), value: vehicleState.speedKmh)
                }

                VStack(spacing: 0) {
                    gearRow
                        .padding(.top, size * 0.12)

                    // 限速牌（TITA 专属）
                    if let limit = vehicleState.speedLimitKmh {
                        speedLimitBadge(limit)
                            .padding(.top, 6)
                    }

                    Spacer()

                    // 传统转向灯 + 盲点警示
                    HStack(spacing: size * 0.16) {
                        blindDot(isLeft: true)
                        if settings.signalStyle == .classic {
                            turnArrow(systemName: "arrow.left", active: vehicleState.leftTurnSignal)
                            turnArrow(systemName: "arrow.right", active: vehicleState.rightTurnSignal)
                        }
                        blindDot(isLeft: false)
                    }
                    .padding(.bottom, 6)

                    Text(speedText)
                        .font(DashboardTheme.monoDigit(size: size * 0.28, weight: .bold))
                        .foregroundStyle(overspeed && flashOn
                                         ? DashboardTheme.accentRed
                                         : DashboardTheme.primaryText)
                        .contentTransition(.numericText())
                        .animation(.linear(duration: 0.1), value: vehicleState.speedKmh)

                    Text(settings.speedUnit.rawValue)
                        .font(.system(size: size * 0.07, weight: .medium))
                        .foregroundStyle(DashboardTheme.secondaryText)
                        .padding(.top, 2)

                    // 红绿灯提示（TITA 专属）
                    if settings.trafficLightMode == .all,
                       let light = vehicleState.trafficLight {
                        trafficLightBadge(light)
                            .padding(.top, 8)
                    }

                    Spacer()
                }
            }
            .frame(width: size, height: size)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
        .onAppear {
            // 超速闪烁定时器
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
                flashOn.toggle()
            }
        }
    }

    // MARK: - 档位（颜色可在设置中自定义）
    private var gearRow: some View {
        HStack(spacing: 28) {
            ForEach(Gear.allCases, id: \.self) { gear in
                Text(gear.rawValue)
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundStyle(
                        vehicleState.gear == gear
                            ? (settings.gearColors[gear] ?? DashboardTheme.gearActive)
                            : DashboardTheme.gearInactive
                    )
            }
        }
    }

    // MARK: - 子组件

    private func signalArc(trim: ClosedRange<Double>) -> some View {
        Circle()
            .trim(from: trim.lowerBound, to: trim.upperBound)
            .stroke(DashboardTheme.accentGreen,
                    style: StrokeStyle(lineWidth: 5, lineCap: .round))
            .rotationEffect(.degrees(-90))
            .opacity(flashOn ? 1 : 0.15)
            .animation(.easeInOut(duration: 0.4), value: flashOn)
    }

    private func turnArrow(systemName: String, active: Bool) -> some View {
        Image(systemName: systemName)
            .font(.system(size: 20, weight: .bold))
            .foregroundStyle(active ? DashboardTheme.accentGreen : Color.clear)
            .opacity(active ? 1 : 0)
            .animation(.easeInOut(duration: 0.4).repeatForever(autoreverses: true), value: active)
    }

    /// 盲点警示灯（常亮/呼吸，始终/仅打转向灯时）
    @ViewBuilder
    private func blindDot(isLeft: Bool) -> some View {
        let detected = isLeft ? vehicleState.blindSpotLeft : vehicleState.blindSpotRight
        let signaling = isLeft ? vehicleState.leftTurnSignal : vehicleState.rightTurnSignal
        let visible = detected && (settings.blindSpotTiming == .always || signaling)

        if visible {
            Circle()
                .fill(DashboardTheme.accentRed)
                .frame(width: 12, height: 12)
                .shadow(color: .red, radius: 6)
                .opacity(settings.blindSpotStyle == .breathing ? (flashOn ? 1 : 0.3) : 1)
                .animation(.easeInOut(duration: 0.5), value: flashOn)
        }
    }

    private func speedLimitBadge(_ limit: Int) -> some View {
        Text("\(limit)")
            .font(DashboardTheme.monoDigit(size: 15, weight: .bold))
            .foregroundStyle(.black)
            .frame(width: 34, height: 34)
            .background(Circle().fill(.white))
            .overlay(Circle().stroke(.red, lineWidth: 3))
    }

    private func trafficLightBadge(_ light: String) -> some View {
        HStack(spacing: 6) {
            Circle()
                .fill(light == "red" ? Color.red : Color.green)
                .frame(width: 12, height: 12)
            Text(light == "red" ? "红灯" : "绿灯")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(DashboardTheme.secondaryText)
        }
    }

    // MARK: - 计算属性

    private var overspeed: Bool {
        settings.overspeedWarning &&
        vehicleState.isOverspeed(mode: settings.overspeedMode, value: settings.overspeedValue)
    }

    private var speedText: String {
        guard let s = vehicleState.speedKmh else { return "—" }
        switch settings.speedUnit {
        case .kmh: return String(format: "%.0f", s)
        case .mph: return String(format: "%.0f", s * 0.621371)
        }
    }

    private var speedColor: Color {
        guard let s = vehicleState.speedKmh else { return .clear }
        switch s {
        case ..<60:   return DashboardTheme.accentGreen
        case ..<120:  return DashboardTheme.accentOrange
        default:      return DashboardTheme.accentRed
        }
    }
}
