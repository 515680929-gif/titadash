import SwiftUI

/// 中央大圆环时速表（环绕式信号灯布局，还原参考图）：
/// 顶部 AP 方向盘 / 左上限速 / 右上红绿灯 / 右 AutoHold / 右下尾门 /
/// 底部车门 / 左下前备箱 / 左 ESP 报警；中心 PRND + 横线时速 + km/h。
/// 所有环绕信号均来自 TITA 发射器数据。
struct SpeedDialView: View {
    @Environment(VehicleState.self) private var vehicleState
    @ObservedObject var settings: AppSettings

    private let maxSpeed: Double = 200
    @State private var flashOn = false

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height) * 0.94
            let u = size / 320 // 基准比例：以 320 直径设计各元素尺寸

            ZStack {
                // 外环（底）
                Circle()
                    .stroke(DashboardTheme.ringTrack, lineWidth: 2)

                // 刹车灯：顶部红色弧（TITA 专属）
                if settings.brakeLight, vehicleState.brakeActive {
                    Circle()
                        .trim(from: 0.43, to: 0.57)
                        .stroke(Color.red, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .shadow(color: .red, radius: 8)
                }

                // 转向灯弧形（TITA 专属）
                if settings.signalStyle == .arc {
                    if vehicleState.leftTurnSignal {
                        signalArc(trim: 0.72...0.92)
                    }
                    if vehicleState.rightTurnSignal {
                        signalArc(trim: 0.08...0.28)
                    }
                }

                // 速度进度弧
                if let speed = vehicleState.speedKmh, speed > 0 {
                    Circle()
                        .trim(from: 0, to: min(speed / maxSpeed, 1.0) * 0.75)
                        .stroke(speedColor,
                                style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .rotationEffect(.degrees(135))
                        .animation(.linear(duration: 0.15), value: vehicleState.speedKmh)
                }

                // ===== 中心内容：PRND + 横线时速 + km/h =====
                VStack(spacing: 0) {
                    gearRow(u: u)
                        .padding(.top, 34 * u)
                    Spacer()
                    Text(speedText)
                        .font(DashboardTheme.monoDigit(size: 58 * u, weight: .bold))
                        .foregroundStyle(overspeed && flashOn
                                         ? DashboardTheme.accentRed
                                         : DashboardTheme.primaryText)
                        .contentTransition(.numericText())
                        .animation(.linear(duration: 0.1), value: vehicleState.speedKmh)
                    Text(settings.speedUnit.rawValue)
                        .font(.system(size: 17 * u, weight: .medium))
                        .foregroundStyle(DashboardTheme.secondaryText)
                        .padding(.top, 2)
                    Spacer()
                }
                .frame(width: size * 0.55)

                // ===== 环绕信号灯 =====
                // 顶部：AP 状态（蓝色方向盘）
                apIndicator(u: u)
                    .offset(y: -size * 0.40)

                // 左上：车机导航限速（红圈）
                speedLimitBadge(u: u)
                    .offset(x: -size * 0.33, y: -size * 0.21)

                // 右上：红绿灯
                trafficLights(u: u)
                    .offset(x: size * 0.33, y: -size * 0.20)

                // 最右：AutoHold
                autoHoldIndicator(u: u)
                    .offset(x: size * 0.42)

                // 右下：尾门未关
                indicator(systemName: "car.side.rear.open",
                          color: DashboardTheme.accentRed,
                          active: vehicleState.trunkOpen, u: u)
                    .offset(x: size * 0.30, y: size * 0.30)

                // 底部：车门未关
                indicator(systemName: "car.side.front.open",
                          color: DashboardTheme.accentRed,
                          active: vehicleState.doorAjar, u: u)
                    .offset(y: size * 0.42)

                // 左下：前备箱未关
                indicator(systemName: "car.side.front.open",
                          color: DashboardTheme.accentRed,
                          active: vehicleState.frunkOpen, u: u)
                    .rotationEffect(.degrees(180))
                    .offset(x: -size * 0.30, y: size * 0.30)

                // 最左：ESP 报警
                indicator(systemName: "car.side",
                          color: DashboardTheme.accentOrange,
                          active: vehicleState.espActive, u: u)
                    .offset(x: -size * 0.42)
            }
            .frame(width: size, height: size)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
        .onAppear {
            // 超速/呼吸闪烁定时器
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
                flashOn.toggle()
            }
        }
    }

    // MARK: - 中心档位（颜色可在设置中自定义）
    private func gearRow(u: CGFloat) -> some View {
        HStack(spacing: 18 * u) {
            ForEach(Gear.allCases, id: \.self) { gear in
                Text(gear.rawValue)
                    .font(.system(size: 24 * u, weight: .bold, design: .rounded))
                    .foregroundStyle(
                        vehicleState.gear == gear
                            ? (settings.gearColors[gear] ?? DashboardTheme.gearActive)
                            : DashboardTheme.gearInactive
                    )
            }
        }
    }

    // MARK: - 通用信号灯图标
    private func indicator(systemName: String, color: Color,
                           active: Bool, u: CGFloat) -> some View {
        Image(systemName: systemName)
            .font(.system(size: 22 * u, weight: .semibold))
            .foregroundStyle(active ? color : DashboardTheme.gearInactive.opacity(0.40))
            .shadow(color: active ? color : .clear, radius: active ? 6 : 0)
            .opacity(active ? 1 : 0.75)
            .animation(.easeInOut(duration: 0.25), value: active)
    }

    // 顶部 AP 方向盘
    private func apIndicator(u: CGFloat) -> some View {
        Image(systemName: "steeringwheel")
            .font(.system(size: 24 * u, weight: .semibold))
            .foregroundStyle(vehicleState.autopilotActive
                             ? Color.blue : DashboardTheme.gearInactive.opacity(0.40))
            .shadow(color: vehicleState.autopilotActive ? .blue : .clear, radius: 6)
            .opacity(vehicleState.autopilotActive ? 1 : 0.75)
    }

    // 最右 AutoHold（H）
    private func autoHoldIndicator(u: CGFloat) -> some View {
        Text("(H)")
            .font(.system(size: 20 * u, weight: .semibold, design: .rounded))
            .foregroundStyle(vehicleState.autoholdActive
                             ? DashboardTheme.primaryText
                             : DashboardTheme.gearInactive.opacity(0.40))
            .shadow(color: vehicleState.autoholdActive ? Color.white.opacity(0.6) : .clear,
                    radius: 5)
    }

    // 右上 红绿灯：红黄绿三灯竖排
    private func trafficLights(u: CGFloat) -> some View {
        VStack(spacing: 3 * u) {
            trafficDot(color: .red, on: vehicleState.trafficLight == "red", u: u)
            trafficDot(color: .yellow, on: vehicleState.trafficLight == "yellow", u: u)
            trafficDot(color: .green, on: vehicleState.trafficLight == "green", u: u)
        }
    }

    private func trafficDot(color: Color, on: Bool, u: CGFloat) -> some View {
        Circle()
            .fill(on ? color : color.opacity(0.22))
            .frame(width: 8 * u, height: 8 * u)
            .shadow(color: on ? color : .clear, radius: on ? 4 : 0)
    }

    // 左上 限速牌：红色小圈
    private func speedLimitBadge(u: CGFloat) -> some View {
        Group {
            if let limit = vehicleState.speedLimitKmh {
                Text("\(limit)")
                    .font(DashboardTheme.monoDigit(size: 14 * u, weight: .bold))
                    .foregroundStyle(.red)
                    .frame(width: 30 * u, height: 30 * u)
                    .background(Circle().fill(Color.red.opacity(0.08)))
                    .overlay(Circle().stroke(Color.red, lineWidth: 2))
            } else {
                Circle()
                    .stroke(DashboardTheme.ringTrack, lineWidth: 1.5)
                    .frame(width: 30 * u, height: 30 * u)
                    .opacity(0.6)
            }
        }
    }

    private func signalArc(trim: ClosedRange<Double>) -> some View {
        Circle()
            .trim(from: trim.lowerBound, to: trim.upperBound)
            .stroke(DashboardTheme.accentGreen,
                    style: StrokeStyle(lineWidth: 5, lineCap: .round))
            .rotationEffect(.degrees(-90))
            .opacity(flashOn ? 1 : 0.15)
            .animation(.easeInOut(duration: 0.4), value: flashOn)
    }

    // MARK: - 计算属性
    private var overspeed: Bool {
        settings.overspeedWarning &&
        vehicleState.isOverspeed(mode: settings.overspeedMode, value: settings.overspeedValue)
    }

    private var speedText: String {
        guard let s = vehicleState.speedKmh else { return "—" }
        switch settings.speedUnit {
        case .kmh: return String(format: "%.0f", s)
        case .mph: return String(format: "%.0f", s * 0.621371)
        }
    }

    private var speedColor: Color {
        guard let s = vehicleState.speedKmh else { return .clear }
        switch s {
        case ..<60:   return DashboardTheme.accentGreen
        case ..<120:  return DashboardTheme.accentOrange
        default:      return DashboardTheme.accentRed
        }
    }
}
