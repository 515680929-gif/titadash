import SwiftUI

/// 横屏仪表盘主页：地图背景 + 左行程统计 / 中大圆环时速表 / 右音乐面板 + 测速提醒卡片
struct DashboardView: View {
    @Environment(VehicleState.self) private var vehicleState
    @Environment(TitaConnectionManager.self) private var connectionManager
    @ObservedObject var settings: AppSettings
    let locationService: LocationService
    let nowPlaying: NowPlayingService
    let speedCamService: SpeedCameraService

    var onOpenSettings: () -> Void
    var onOpenConnection: () -> Void

    /// 用于行程时间每秒刷新
    @State private var now = Date()
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    /// 左侧面板三态循环：行驶数据 → 地图+导航 → 胎压
    enum LeftPanelPage: Int { case stats = 0, map = 1, tires = 2 }
    @State private var leftPage: LeftPanelPage = .stats

    var body: some View {
        GeometryReader { geo in
            let landscape = geo.size.width >= geo.size.height
            ZStack {
                DashboardTheme.background.ignoresSafeArea()

                // 地图背景层（右侧渐隐到黑，对应参考图的地图渐变效果）
                if settings.mapEnabled {
                    MapPanelView(settings: settings, locationService: locationService)
                        .ignoresSafeArea()
                        .opacity(0.72)
                        .mask(
                            LinearGradient(
                                gradient: Gradient(stops: [
                                    .init(color: .white, location: 0),
                                    .init(color: .white, location: 0.30),
                                    .init(color: .white.opacity(0.35), location: 0.52),
                                    .init(color: .clear, location: 0.72)
                                ]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .allowsHitTesting(false)
                }

                VStack(spacing: 0) {
                    TopStatusBarView(
                        onOpenSettings: onOpenSettings,
                        onOpenConnection: onOpenConnection,
                        compact: !landscape
                    )

                    // 测速提醒卡片（对应「提示卡片」设置）
                    if settings.speedCamCard, let alert = speedCamService.currentAlert {
                        SpeedCamAlertCardView(alert: alert)
                            .padding(.horizontal, landscape ? 40 : 16)
                            .padding(.top, 4)
                            .animation(.spring(duration: 0.3),
                                       value: speedCamService.currentAlert)
                    }

                    if landscape {
                        landscapeContent
                    } else {
                        portraitContent(in: geo)
                    }

                    bottomBar(compact: !landscape)
                        .padding(.horizontal, landscape ? 32 : 20)
                        .padding(.bottom, 14)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        // 显示大小：整体缩放（对应「显示大小-放大仪表板的文字与卡片」）
        .scaleEffect(settings.uiScale)
        // HUD 模式：镜像翻转（前挡反射用）+ 高对比纯色
        .scaleEffect(x: settings.hudMode == .off ? 1 : -1, y: 1)
        .onReceive(ticker) { now = $0 }
    }

    // MARK: - 横屏：左数据 / 中圆环 / 右音乐 三栏
    private var landscapeContent: some View {
        HStack(alignment: .center, spacing: 0) {
            leftPanel(compact: false)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 32)
                .contentShape(Rectangle())
                .onTapGesture(count: 2) { cycleLeftPage() }

            SpeedDialView(settings: settings)
                .frame(maxWidth: .infinity)

            MusicPanelView(nowPlaying: nowPlaying)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.trailing, 32)
        }
        .frame(maxHeight: .infinity)
    }

    // MARK: - 竖屏：上方大圆环 + 下方左右两卡片
    private func portraitContent(in geo: GeometryProxy) -> some View {
        // 圆环直径：同时受宽度、高度约束，避免小屏或矮屏溢出
        let dial = min(geo.size.width - 32, geo.size.height * 0.44, 330)
        return VStack(spacing: 0) {
            SpeedDialView(settings: settings)
                .frame(width: dial, height: dial)
                .padding(.top, 6)

            Spacer(minLength: 6)

            HStack(alignment: .center, spacing: 14) {
                leftPanel(compact: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .contentShape(Rectangle())
                    .onTapGesture(count: 2) { cycleLeftPage() }

                MusicPanelView(nowPlaying: nowPlaying, compact: true)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
            .padding(.horizontal, 20)
            .frame(minHeight: 190)
        }
        .frame(maxHeight: .infinity)
    }

    /// 左侧三态面板：行程数据 → 纯地图 → 胎压
    @ViewBuilder
    private func leftPanel(compact: Bool) -> some View {
        switch leftPage {
        case .map:
            // 纯地图：不叠加行程数据/导航卡片，右侧渐隐融入背景
            MapPanelView(settings: settings,
                         locationService: locationService)
                .frame(maxWidth: compact ? 200 : 420,
                       maxHeight: compact ? 200 : 420)
                .mask(
                    LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: .white, location: 0),
                            .init(color: .white, location: 0.65),
                            .init(color: .clear, location: 1)
                        ]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(DashboardTheme.ringTrack, lineWidth: 1)
                )
        case .tires:
            TirePressureView()
                .frame(maxWidth: compact ? 200 : 340)
        case .stats:
            StatsPanelView(now: now)
        }
    }

    private func cycleLeftPage() {
        withAnimation(.easeInOut(duration: 0.25)) {
            leftPage = LeftPanelPage(rawValue: (leftPage.rawValue + 1) % 3) ?? .stats
        }
    }

    // MARK: - 底部：电量/续航 + ODO
    private func bottomBar(compact: Bool) -> some View {
        HStack {
            HStack(spacing: 8) {
                batteryIcon
                Text(batteryText)
                    .font(DashboardTheme.monoDigit(size: compact ? 16 : 20))
                    .foregroundStyle(DashboardTheme.primaryText)
                    .fixedSize(horizontal: true, vertical: false)
            }

            // 实时位置（仅横屏置底时显示；竖屏空间不足，自动省略避免换行挤压）
            if !compact,
               settings.realtimePosition == .bottom,
               let coord = locationService.coordinate {
                Spacer()
                Text(String(format: "%.5f, %.5f", coord.latitude, coord.longitude))
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(DashboardTheme.secondaryText)
                    .onTapGesture {
                        // 点一下快速切换（对应设置说明）
                        settings.realtimePosition = .top
                    }
            }

            Spacer()
            Text("ODO \(odometerText)")
                .font(DashboardTheme.monoDigit(size: compact ? 16 : 20))
                .foregroundStyle(DashboardTheme.secondaryText)
                .fixedSize(horizontal: true, vertical: false)
        }
    }

    private var batteryIcon: some View {
        let percent = vehicleState.batteryPercent
        let fill = CGFloat(percent ?? 0) / 100.0
        return ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 3)
                .stroke(DashboardTheme.placeholder, lineWidth: 1.5)
                .frame(width: 44, height: 18)
            RoundedRectangle(cornerRadius: 2)
                .fill(DashboardTheme.batteryColor(for: percent))
                .frame(width: max(0, 40 * fill), height: 14)
                .padding(.leading, 2)
        }
    }

    private var batteryText: String {
        guard let p = vehicleState.batteryPercent else { return "--% / --km" }
        let range = vehicleState.rangeKm.map { String(format: "%.0f", $0) } ?? "--"
        return "\(p)% / \(range)km"
    }

    private var odometerText: String {
        guard let odo = vehicleState.odometerKm else { return "--km" }
        return String(format: "%.0fkm", odo)
    }
}
