import SwiftUI

/// 横屏仪表盘主页：地图背景 + 左面板 / 中圆环时速表 / 右面板 + 测速提醒卡片。
/// 左右面板均可上下滑动切换内容，且同一内容左右都能显示（页面池共用）。
struct DashboardView: View {
    @Environment(VehicleState.self) private var vehicleState
    @ObservedObject var settings: AppSettings
    let locationService: LocationService
    let nowPlaying: NowPlayingService
    let speedCamService: SpeedCameraService

    var onOpenSettings: () -> Void
    var onOpenConnection: () -> Void

    @State private var now = Date()
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    // 左右面板各自当前页（页面池共用，故同一内容可左右互换）
    @State private var leftPage: PanelPage = .stats
    @State private var rightPage: PanelPage = .music

    /// 可切换的面板内容池
    enum PanelPage: String, CaseIterable, Identifiable {
        case stats, map, tires, music, lyrics, nav, signal
        var id: String { rawValue }
        var label: String {
            switch self {
            case .stats:  return "行驶数据"
            case .map:    return "地图"
            case .tires:  return "胎压"
            case .music:  return "音乐"
            case .lyrics: return "歌词"
            case .nav:    return "导航"
            case .signal: return "信号来源"
            }
        }
    }

    var body: some View {
        GeometryReader { geo in
            let landscape = geo.size.width >= geo.size.height
            ZStack {
                DashboardTheme.background.ignoresSafeArea()

                // 地图背景层：左侧渐隐到黑、右侧清晰（对应参考图右侧地图效果）
                if settings.mapEnabled {
                    mapBackground
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                }

                VStack(spacing: 0) {
                    TopStatusBarView(
                        onOpenSettings: onOpenSettings,
                        onOpenConnection: onOpenConnection,
                        compact: !landscape
                    )

                    if settings.speedCamCard, let alert = speedCamService.currentAlert {
                        SpeedCamAlertCardView(alert: alert)
                            .padding(.horizontal, landscape ? 40 : 16)
                            .padding(.top, 4)
                            .animation(.spring(duration: 0.3),
                                       value: speedCamService.currentAlert)
                    }

                    if landscape {
                        landscapeContent
                    } else {
                        portraitContent(in: geo)
                    }

                    bottomBar(compact: !landscape)
                        .padding(.horizontal, landscape ? 32 : 20)
                        .padding(.bottom, 14)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .scaleEffect(settings.uiScale)
        .scaleEffect(x: settings.hudMode == .off ? 1 : -1, y: 1)
        .onReceive(ticker) { now = $0 }
    }

    // MARK: - 横屏：左面板 / 中圆环 / 右面板 三栏
    private var landscapeContent: some View {
        HStack(alignment: .center, spacing: 0) {
            panelSwitcher(page: $leftPage, compact: false)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 24)

            SpeedDialView(settings: settings)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            panelSwitcher(page: $rightPage, compact: false)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.trailing, 24)
        }
        .frame(maxHeight: .infinity)
    }

    // MARK: - 竖屏：上方大圆环 + 下方左右两面板
    private func portraitContent(in geo: GeometryProxy) -> some View {
        let dial = min(geo.size.width - 32, geo.size.height * 0.42, 330)
        return VStack(spacing: 0) {
            SpeedDialView(settings: settings)
                .frame(width: dial, height: dial)
                .padding(.top, 4)

            Spacer(minLength: 6)

            HStack(alignment: .center, spacing: 14) {
                panelSwitcher(page: $leftPage, compact: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
                panelSwitcher(page: $rightPage, compact: true)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
            .padding(.horizontal, 18)
            .frame(minHeight: 190)
        }
        .frame(maxHeight: .infinity)
    }

    // MARK: - 面板切换器：上下滑动循环切换，底部小圆点指示当前页
    @ViewBuilder
    private func panelSwitcher(page: Binding<PanelPage>, compact: Bool) -> some View {
        let height: CGFloat = compact ? 200 : 340
        VStack(spacing: 8) {
            ZStack {
                panelContent(page.wrappedValue, compact: compact)
            }
            .frame(maxWidth: .infinity, minHeight: height, maxHeight: height)
            .clipped()
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 28)
                    .onEnded { value in
                        let dy = value.translation.height
                        guard abs(dy) > 36 else { return }
                        let pages = PanelPage.allCases
                        let idx = pages.firstIndex(of: page.wrappedValue) ?? 0
                        let next = dy < 0
                            ? (idx + 1) % pages.count                 // 上滑 → 下一页
                            : (idx - 1 + pages.count) % pages.count   // 下滑 → 上一页
                        withAnimation(.easeInOut(duration: 0.25)) {
                            page.wrappedValue = pages[next]
                        }
                    }
            )
            .onTapGesture(count: 2) {
                let pages = PanelPage.allCases
                let idx = pages.firstIndex(of: page.wrappedValue) ?? 0
                withAnimation(.easeInOut(duration: 0.25)) {
                    page.wrappedValue = pages[(idx + 1) % pages.count]
                }
            }

            // 分页指示点
            HStack(spacing: 5) {
                ForEach(PanelPage.allCases) { p in
                    Circle()
                        .fill(p == page.wrappedValue
                              ? DashboardTheme.accentGreen
                              : DashboardTheme.ringTrack)
                        .frame(width: 5, height: 5)
                }
            }
        }
    }

    /// 页面池：同一个视图可被左侧或右侧复用
    @ViewBuilder
    private func panelContent(_ page: PanelPage, compact: Bool) -> some View {
        switch page {
        case .stats:
            StatsPanelView(now: now)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        case .map:
            MapPanelView(settings: settings, locationService: locationService)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(DashboardTheme.ringTrack, lineWidth: 1)
                )
        case .tires:
            TirePressureView()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        case .music:
            MusicPanelView(nowPlaying: nowPlaying, compact: compact)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        case .lyrics:
            MusicPanelView(nowPlaying: nowPlaying, compact: compact, startWithLyrics: true)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        case .nav:
            NavInfoPanelView()
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        case .signal:
            SignalSourceView(locationService: locationService)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    // MARK: - 地图背景（左黑右清晰）
    private var mapBackground: some View {
        MapPanelView(settings: settings, locationService: locationService)
            .opacity(0.75)
            .mask(
                LinearGradient(
                    gradient: Gradient(stops: [
                        .init(color: .clear,  location: 0),
                        .init(color: .clear,  location: 0.22),
                        .init(color: .white.opacity(0.35), location: 0.45),
                        .init(color: .white, location: 0.78),
                        .init(color: .white, location: 1)
                    ]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
    }

    // MARK: - 底部：电量/续航 + ODO
    private func bottomBar(compact: Bool) -> some View {
        HStack {
            HStack(spacing: 8) {
                batteryIcon
                Text(batteryText)
                    .font(DashboardTheme.monoDigit(size: compact ? 16 : 20))
                    .foregroundStyle(DashboardTheme.primaryText)
                    .fixedSize(horizontal: true, vertical: false)
            }

            if !compact,
               settings.realtimePosition == .bottom,
               let coord = locationService.coordinate {
                Spacer()
                Text(String(format: "%.5f, %.5f", coord.latitude, coord.longitude))
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(DashboardTheme.secondaryText)
                    .onTapGesture { settings.realtimePosition = .top }
            }

            Spacer()
            Text("ODO \(odometerText)")
                .font(DashboardTheme.monoDigit(size: compact ? 16 : 20))
                .foregroundStyle(DashboardTheme.secondaryText)
                .fixedSize(horizontal: true, vertical: false)
        }
    }

    private var batteryIcon: some View {
        let percent = vehicleState.batteryPercent
        let fill = CGFloat(percent ?? 0) / 100.0
        return ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 3)
                .stroke(DashboardTheme.placeholder, lineWidth: 1.5)
                .frame(width: 44, height: 18)
            RoundedRectangle(cornerRadius: 2)
                .fill(DashboardTheme.batteryColor(for: percent))
                .frame(width: max(0, 40 * fill), height: 14)
                .padding(.leading, 2)
        }
    }

    private var batteryText: String {
        guard let p = vehicleState.batteryPercent else { return "--% / --km" }
        let range = vehicleState.rangeKm.map { String(format: "%.0f", $0) } ?? "--"
        return "\(p)% / \(range)km"
    }

    private var odometerText: String {
        guard let odo = vehicleState.odometerKm else { return "--km" }
        return String(format: "%.0fkm", odo)
    }
}
