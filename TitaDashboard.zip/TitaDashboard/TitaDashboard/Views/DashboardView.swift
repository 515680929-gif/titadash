import SwiftUI

/// 横屏仪表盘主页：地图背景 + 左行程统计 / 中大圆环时速表 / 右音乐面板 + 测速提醒卡片
struct DashboardView: View {
    @Environment(VehicleState.self) private var vehicleState
    @Environment(TitaConnectionManager.self) private var connectionManager
    @ObservedObject var settings: AppSettings
    let locationService: LocationService
    let nowPlaying: NowPlayingService
    let speedCamService: SpeedCameraService

    var onOpenSettings: () -> Void
    var onOpenConnection: () -> Void

    /// 用于行程时间每秒刷新
    @State private var now = Date()
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    /// 左侧面板：默认行驶数据，双击切换地图
    @State private var leftShowMap = false

    var body: some View {
        ZStack {
            DashboardTheme.background.ignoresSafeArea()

            // 地图背景层（可在设置中开关，对应截图1的地图底图效果）
            if settings.mapEnabled {
                MapPanelView(settings: settings, locationService: locationService)
                    .ignoresSafeArea()
                    .opacity(0.45)
                    .allowsHitTesting(false)
            }

            VStack(spacing: 0) {
                TopStatusBarView(
                    onOpenSettings: onOpenSettings,
                    onOpenConnection: onOpenConnection
                )

                // 测速提醒卡片（对应「提示卡片」设置）
                if settings.speedCamCard, let alert = speedCamService.currentAlert {
                    SpeedCamAlertCardView(alert: alert)
                        .padding(.horizontal, 40)
                        .padding(.top, 4)
                        .animation(.spring(duration: 0.3),
                                   value: speedCamService.currentAlert)
                }

                HStack(alignment: .center, spacing: 0) {
                    // 左侧：默认行驶数据，双击切换地图
                    Group {
                        if leftShowMap {
                            MapPanelView(settings: settings,
                                         locationService: locationService)
                                .frame(maxWidth: 320, maxHeight: 320)
                                .clipShape(RoundedRectangle(cornerRadius: 18))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 18)
                                        .stroke(DashboardTheme.ringTrack, lineWidth: 1)
                                )
                        } else {
                            StatsPanelView(now: now)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 32)
                    .contentShape(Rectangle())
                    .onTapGesture(count: 2) {
                        withAnimation(.easeInOut(duration: 0.25)) {
                            leftShowMap.toggle()
                        }
                    }

                    SpeedDialView(settings: settings)
                        .frame(maxWidth: .infinity)

                    MusicPanelView(nowPlaying: nowPlaying)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .padding(.trailing, 32)
                }
                .frame(maxHeight: .infinity)

                bottomBar
                    .padding(.horizontal, 32)
                    .padding(.bottom, 14)
            }
        }
        // 显示大小：整体缩放（对应「显示大小-放大仪表板的文字与卡片」）
        .scaleEffect(settings.uiScale)
        // HUD 模式：镜像翻转（前挡反射用）+ 高对比纯色
        .scaleEffect(x: settings.hudMode == .off ? 1 : -1, y: 1)
        .onReceive(ticker) { now = $0 }
    }

    // MARK: - 底部：电量/续航 + ODO
    private var bottomBar: some View {
        HStack {
            HStack(spacing: 8) {
                batteryIcon
                Text(batteryText)
                    .font(DashboardTheme.monoDigit(size: 20))
                    .foregroundStyle(DashboardTheme.primaryText)
            }

            // 实时位置（置底时显示在底栏中间）
            if settings.realtimePosition == .bottom,
               let coord = locationService.coordinate {
                Spacer()
                Text(String(format: "%.5f, %.5f", coord.latitude, coord.longitude))
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(DashboardTheme.secondaryText)
                    .onTapGesture {
                        // 点一下快速切换（对应设置说明）
                        settings.realtimePosition = .top
                    }
            }

            Spacer()
            Text("ODO \(odometerText)")
                .font(DashboardTheme.monoDigit(size: 20))
                .foregroundStyle(DashboardTheme.secondaryText)
        }
    }

    private var batteryIcon: some View {
        let percent = vehicleState.batteryPercent
        let fill = CGFloat(percent ?? 0) / 100.0
        return ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 3)
                .stroke(DashboardTheme.placeholder, lineWidth: 1.5)
                .frame(width: 44, height: 18)
            RoundedRectangle(cornerRadius: 2)
                .fill(DashboardTheme.batteryColor(for: percent))
                .frame(width: max(0, 40 * fill), height: 14)
                .padding(.leading, 2)
        }
    }

    private var batteryText: String {
        guard let p = vehicleState.batteryPercent else { return "--% / --km" }
        let range = vehicleState.rangeKm.map { String(format: "%.0f", $0) } ?? "--"
        return "\(p)% / \(range)km"
    }

    private var odometerText: String {
        guard let odo = vehicleState.odometerKm else { return "--km" }
        return String(format: "%.0fkm", odo)
    }
}
