import Foundation
import SwiftUI
import UIKit
import Combine

/// 全局设置中心：对应截图中全部设置项，UserDefaults 持久化。
final class AppSettings: ObservableObject {

    // MARK: - 偏好设置
    enum AppTheme: String, CaseIterable { case light = "浅色", dark = "深色", auto = "自动" }
    enum DisplaySize: String, CaseIterable { case small = "小", medium = "中", large = "大" }
    enum DriverSide: String, CaseIterable { case left = "左", right = "右" }
    enum BackgroundMode: String, CaseIterable { case off = "关闭", pip = "PiP", dynamicIsland = "灵动岛" }
    enum HUDMode: String, CaseIterable { case off = "关闭", solid = "纯色", color = "彩色" }
    enum RefreshMode: String, CaseIterable { case saver = "节能", balanced = "平衡", performance = "高性能" }

    @Published var theme: AppTheme { didSet { save(theme.rawValue, "theme") } }
    @Published var displaySize: DisplaySize { didSet { save(displaySize.rawValue, "displaySize") } }
    @Published var driverSide: DriverSide { didSet { save(driverSide.rawValue, "driverSide") } }
    @Published var backgroundMode: BackgroundMode { didSet { save(backgroundMode.rawValue, "backgroundMode") } }
    @Published var hudMode: HUDMode { didSet { save(hudMode.rawValue, "hudMode") } }
    @Published var refreshMode: RefreshMode { didSet { save(refreshMode.rawValue, "refreshMode") } }
    @Published var voiceVolume: Double { didSet { save(voiceVolume, "voiceVolume") } } // 0~1

    // MARK: - 仪表盘样式
    enum Orientation: String, CaseIterable { case portrait = "竖屏", landscapeLeft = "横屏左", landscapeRight = "横屏右", auto = "自动" }
    enum SpeedoStyle: String, CaseIterable { case classic = "经典", simple = "简约" }
    enum MotorPowerStyle: String, CaseIterable { case top = "顶部", ring = "圆环", off = "关闭" }
    enum PositionSlot: String, CaseIterable { case top = "置顶", bottom = "置底", off = "关闭" }
    enum TempDisplay: String, CaseIterable { case both = "两者", outside = "车外", inside = "车内" }

    @Published var orientation: Orientation { didSet { save(orientation.rawValue, "orientation") } }
    @Published var speedoStyle: SpeedoStyle { didSet { save(speedoStyle.rawValue, "speedoStyle") } }
    @Published var gearColors: [Gear: Color] { didSet { saveGearColors() } }
    @Published var motorPowerStyle: MotorPowerStyle { didSet { save(motorPowerStyle.rawValue, "motorPowerStyle") } }
    @Published var realtimePosition: PositionSlot { didSet { save(realtimePosition.rawValue, "realtimePosition") } }
    @Published var tempDisplay: TempDisplay { didSet { save(tempDisplay.rawValue, "tempDisplay") } }

    // MARK: - 地图
    enum MapProvider: String, CaseIterable { case apple = "Apple", google = "Google" }
    enum LocationMode: String, CaseIterable { case phone = "手机 GPS", car = "车机 GPS", fusion = "Fusion GPS" }
    enum NavIcon: String, CaseIterable {
        case simple = "简约", realistic = "拟真"
        case model3 = "Model 3", modelY = "Model Y"
        case roadster = "Roadster", cybertruck = "Cybertruck", semi = "Semi", cybercab = "Cybercab"
    }
    enum IconAnchor: String, CaseIterable { case center = "地图正中央", avoidPanel = "避开面板" }

    @Published var mapEnabled: Bool { didSet { save(mapEnabled, "mapEnabled") } }
    @Published var mapProvider: MapProvider { didSet { save(mapProvider.rawValue, "mapProvider") } }
    @Published var locationMode: LocationMode { didSet { save(locationMode.rawValue, "locationMode") } }
    @Published var mapAutoZoom: Bool { didSet { save(mapAutoZoom, "mapAutoZoom") } }
    @Published var junction2D: Bool { didSet { save(junction2D, "junction2D") } }
    @Published var navVoiceEnabled: Bool { didSet { save(navVoiceEnabled, "navVoiceEnabled") } }
    @Published var navIcon: NavIcon { didSet { save(navIcon.rawValue, "navIcon") } }
    @Published var navIcon3D: Bool { didSet { save(navIcon3D, "navIcon3D") } }
    @Published var iconAnchor: IconAnchor { didSet { save(iconAnchor.rawValue, "iconAnchor") } }

    // MARK: - 歌词播放器
    enum LyricsSource: String, CaseIterable { case lrclib = "LRCLIB", musixmatch = "Musixmatch" }

    @Published var lyricsSource: LyricsSource { didSet { save(lyricsSource.rawValue, "lyricsSource") } }
    @Published var lyricsAgreed: Bool { didSet { save(lyricsAgreed, "lyricsAgreed") } }
    @Published var lyricsDBUrl: String { didSet { save(lyricsDBUrl, "lyricsDBUrl") } }

    // MARK: - 测速照相
    enum PassNotice: String, CaseIterable { case voice = "语音", sfx = "音效" }
    enum AlertTiming: String, CaseIterable { case always = "始终", overspeed = "超速时" }
    enum ThresholdMode: String, CaseIterable { case fixed = "固定值", percent = "百分比" }

    @Published var speedCamEnabled: Bool { didSet { save(speedCamEnabled, "speedCamEnabled") } }
    @Published var speedCamCard: Bool { didSet { save(speedCamCard, "speedCamCard") } }
    @Published var speedCamSound: Bool { didSet { save(speedCamSound, "speedCamSound") } }
    @Published var speedCamPassNotice: PassNotice { didSet { save(speedCamPassNotice.rawValue, "speedCamPassNotice") } }
    @Published var speedCamFixed: Bool { didSet { save(speedCamFixed, "speedCamFixed") } }
    @Published var speedCamMobile: Bool { didSet { save(speedCamMobile, "speedCamMobile") } }
    @Published var speedCamTiming: AlertTiming { didSet { save(speedCamTiming.rawValue, "speedCamTiming") } }
    @Published var speedCamThresholdMode: ThresholdMode { didSet { save(speedCamThresholdMode.rawValue, "speedCamThresholdMode") } }
    @Published var speedCamThresholdValue: Double { didSet { save(speedCamThresholdValue, "speedCamThresholdValue") } }
    @Published var speedCamTech: Bool { didSet { save(speedCamTech, "speedCamTech") } }
    @Published var speedCamSection: Bool { didSet { save(speedCamSection, "speedCamSection") } }
    @Published var speedCamAutoUpdate: Bool { didSet { save(speedCamAutoUpdate, "speedCamAutoUpdate") } }

    // MARK: - 单位格式
    enum SpeedUnit: String, CaseIterable { case kmh = "km/h", mph = "mph" }
    @Published var speedUnit: SpeedUnit { didSet { save(speedUnit.rawValue, "speedUnit") } }

    // MARK: - TITA 专属（需发射器数据支持）
    enum BlindSpotStyle: String, CaseIterable { case always = "常亮", breathing = "呼吸灯" }
    enum BlindSpotTiming: String, CaseIterable { case always = "始终", onSignal = "打转向灯时" }
    enum SignalStyle: String, CaseIterable { case classic = "传统", arc = "弧形" }
    enum TrafficLightMode: String, CaseIterable { case off = "关闭", all = "全部" }
    enum GreenChimeDelay: String, CaseIterable { case now = "立即", s1 = "1s", s3 = "3s" }

    @Published var blindSpotStyle: BlindSpotStyle { didSet { save(blindSpotStyle.rawValue, "blindSpotStyle") } }
    @Published var blindSpotTiming: BlindSpotTiming { didSet { save(blindSpotTiming.rawValue, "blindSpotTiming") } }
    @Published var signalStyle: SignalStyle { didSet { save(signalStyle.rawValue, "signalStyle") } }
    @Published var seatbeltWarning: Bool { didSet { save(seatbeltWarning, "seatbeltWarning") } }
    @Published var brakeLight: Bool { didSet { save(brakeLight, "brakeLight") } }
    @Published var overspeedWarning: Bool { didSet { save(overspeedWarning, "overspeedWarning") } }
    @Published var overspeedMode: ThresholdMode { didSet { save(overspeedMode.rawValue, "overspeedMode") } }
    @Published var overspeedValue: Double { didSet { save(overspeedValue, "overspeedValue") } }
    @Published var trafficLightMode: TrafficLightMode { didSet { save(trafficLightMode.rawValue, "trafficLightMode") } }
    @Published var greenLightChime: Bool { didSet { save(greenLightChime, "greenLightChime") } }
    @Published var greenChimeDelay: GreenChimeDelay { didSet { save(greenChimeDelay.rawValue, "greenChimeDelay") } }

    // MARK: - 初始化（从 UserDefaults 读回）
    init() {
        let d = UserDefaults.standard
        func str(_ key: String, _ def: String) -> String { d.string(forKey: key) ?? def }
        func bool(_ key: String, _ def: Bool) -> Bool { d.object(forKey: key) as? Bool ?? def }
        func dbl(_ key: String, _ def: Double) -> Double { d.object(forKey: key) as? Double ?? def }

        theme = AppTheme(rawValue: str("theme", "auto")) ?? .auto
        displaySize = DisplaySize(rawValue: str("displaySize", "中")) ?? .medium
        driverSide = DriverSide(rawValue: str("driverSide", "左")) ?? .left
        backgroundMode = BackgroundMode(rawValue: str("backgroundMode", "关闭")) ?? .off
        hudMode = HUDMode(rawValue: str("hudMode", "关闭")) ?? .off
        refreshMode = RefreshMode(rawValue: str("refreshMode", "平衡")) ?? .balanced
        voiceVolume = dbl("voiceVolume", 0.4)

        orientation = Orientation(rawValue: str("orientation", "自动")) ?? .auto
        speedoStyle = SpeedoStyle(rawValue: str("speedoStyle", "经典")) ?? .classic
        motorPowerStyle = MotorPowerStyle(rawValue: str("motorPowerStyle", "圆环")) ?? .ring
        realtimePosition = PositionSlot(rawValue: str("realtimePosition", "置底")) ?? .bottom
        tempDisplay = TempDisplay(rawValue: str("tempDisplay", "两者")) ?? .both
        gearColors = Self.loadGearColors()

        mapEnabled = bool("mapEnabled", false)
        mapProvider = MapProvider(rawValue: str("mapProvider", "Apple")) ?? .apple
        locationMode = LocationMode(rawValue: str("locationMode", "手机 GPS")) ?? .phone
        mapAutoZoom = bool("mapAutoZoom", true)
        junction2D = bool("junction2D", false)
        navVoiceEnabled = bool("navVoiceEnabled", false)
        navIcon = NavIcon(rawValue: str("navIcon", "拟真")) ?? .realistic
        navIcon3D = bool("navIcon3D", false)
        iconAnchor = IconAnchor(rawValue: str("iconAnchor", "避开面板")) ?? .avoidPanel

        lyricsSource = LyricsSource(rawValue: str("lyricsSource", "LRCLIB")) ?? .lrclib
        lyricsAgreed = bool("lyricsAgreed", false)
        lyricsDBUrl = str("lyricsDBUrl", "https://lrclib.net")

        speedCamEnabled = bool("speedCamEnabled", true)
        speedCamCard = bool("speedCamCard", true)
        speedCamSound = bool("speedCamSound", true)
        speedCamPassNotice = PassNotice(rawValue: str("speedCamPassNotice", "音效")) ?? .sfx
        speedCamFixed = bool("speedCamFixed", true)
        speedCamMobile = bool("speedCamMobile", true)
        speedCamTiming = AlertTiming(rawValue: str("speedCamTiming", "始终")) ?? .always
        speedCamThresholdMode = ThresholdMode(rawValue: str("speedCamThresholdMode", "固定值")) ?? .fixed
        speedCamThresholdValue = dbl("speedCamThresholdValue", 5)
        speedCamTech = bool("speedCamTech", true)
        speedCamSection = bool("speedCamSection", true)
        speedCamAutoUpdate = bool("speedCamAutoUpdate", false)

        speedUnit = SpeedUnit(rawValue: str("speedUnit", "km/h")) ?? .kmh

        blindSpotStyle = BlindSpotStyle(rawValue: str("blindSpotStyle", "常亮")) ?? .always
        blindSpotTiming = BlindSpotTiming(rawValue: str("blindSpotTiming", "始终")) ?? .always
        signalStyle = SignalStyle(rawValue: str("signalStyle", "传统")) ?? .classic
        seatbeltWarning = bool("seatbeltWarning", true)
        brakeLight = bool("brakeLight", true)
        overspeedWarning = bool("overspeedWarning", true)
        overspeedMode = ThresholdMode(rawValue: str("overspeedMode", "固定值")) ?? .fixed
        overspeedValue = dbl("overspeedValue", 0)
        trafficLightMode = TrafficLightMode(rawValue: str("trafficLightMode", "全部")) ?? .all
        greenLightChime = bool("greenLightChime", true)
        greenChimeDelay = GreenChimeDelay(rawValue: str("greenChimeDelay", "立即")) ?? .now
    }

    /// 显示大小 → 全局缩放系数
    var uiScale: CGFloat {
        switch displaySize {
        case .small: return 0.88
        case .medium: return 1.0
        case .large: return 1.12
        }
    }

    /// 刷新模式 → 数据节流间隔（秒）
    var refreshInterval: TimeInterval {
        switch refreshMode {
        case .saver: return 0.25      // 4Hz
        case .balanced: return 0.1    // 10Hz
        case .performance: return 0.05 // 20Hz
        }
    }

    // MARK: - 持久化
    private func save(_ value: Any, _ key: String) {
        UserDefaults.standard.set(value, forKey: key)
    }

    private func saveGearColors() {
        var raw: [String: String] = [:]
        for (gear, color) in gearColors {
            raw[gear.rawValue] = UIColor(color).toHex()
        }
        UserDefaults.standard.set(raw, forKey: "gearColors")
    }

    static func loadGearColors() -> [Gear: Color] {
        let defaults: [Gear: Color] = [
            .park: Color(hue: 0.75, saturation: 0.6, brightness: 0.95),
            .reverse: Color(hue: 0.55, saturation: 0.6, brightness: 0.95),
            .neutral: Color(hue: 0.35, saturation: 0.5, brightness: 0.9),
            .drive: Color(hue: 0.05, saturation: 0.6, brightness: 0.95)
        ]
        guard let dict = UserDefaults.standard.dictionary(forKey: "gearColors") as? [String: String] else {
            return defaults
        }
        var result = defaults
        for (k, hex) in dict {
            if let gear = Gear(rawValue: k), let c = UIColor(hex: hex) {
                result[gear] = Color(uiColor: c)
            }
        }
        return result
    }
}

// MARK: - 颜色十六进制工具
extension UIColor {
    convenience init?(hex: String) {
        var s = hex.trimmingCharacters(in: .alphanumerics.inverted)
        if s.count == 6 { s += "FF" }
        guard s.count == 8, let v = UInt64(s, radix: 16) else { return nil }
        self.init(red: CGFloat((v >> 24) & 0xFF) / 255,
                  green: CGFloat((v >> 16) & 0xFF) / 255,
                  blue: CGFloat((v >> 8) & 0xFF) / 255,
                  alpha: CGFloat(v & 0xFF) / 255)
    }
    func toHex() -> String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "%02X%02X%02X%02X",
                      Int(r * 255), Int(g * 255), Int(b * 255), Int(a * 255))
    }
}
