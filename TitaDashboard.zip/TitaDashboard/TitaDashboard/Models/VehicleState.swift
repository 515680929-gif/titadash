import Foundation
import Observation

/// 档位
enum Gear: String, CaseIterable {
    case park = "P", reverse = "R", neutral = "N", drive = "D"
}

/// 全局车辆状态：由连接层写入，UI 只读。
@Observable
final class VehicleState {
    // MARK: - 实时车况（来自 TITA 发射器）
    var speedKmh: Double? = nil          // 车速 km/h
    var gear: Gear? = nil                // 当前档位
    var batteryPercent: Int? = nil       // 电量 %
    var rangeKm: Double? = nil           // 预估续航 km
    var odometerKm: Double? = nil        // 总里程 ODO
    var outsideTempC: Double? = nil      // 车外温度
    var insideTempC: Double? = nil       // 车内温度
    var powerKw: Double? = nil           // 实时功率 kW（正=驱动，负=回收）
    var leftTurnSignal = false
    var rightTurnSignal = false
    var autopilotActive = false
    var blindSpotLeft = false
    var blindSpotRight = false
    var tirePressure: [Double] = []      // 四轮胎压 bar [FL,FR,RL,RR]（若发射器提供）
    var tireTemperature: [Double] = []   // 四轮温度 ℃ [FL,FR,RL,RR]
    var brakeActive = false              // 刹车（TITA 专属）
    var speedLimitKmh: Int? = nil        // 道路限速（TITA 专属）
    var seatbeltFastened: Bool? = nil    // 安全带（TITA 专属）
    var trafficLight: String? = nil      // 红绿灯 "red"/"green"/nil（TITA 专属）
    var doorAjar = false                 // 车门未关
    var headlightsOn = false             // 大灯（TITA 专属）
    var hazardOn = false                 // 双闪（TITA 专属）
    var autoholdActive = false           // 自动驻车 Auto Hold（TITA 专属）
    var trunkOpen = false                // 尾门未关（TITA 专属）
    var frunkOpen = false                // 前备箱未关（TITA 专属）
    var espActive = false                // ESP 车身稳定报警（TITA 专属）

    // MARK: - 导航详情（来自 TITA / BLE）
    var navEta: String? = nil            // 预计到达 "14:30"
    var navRemainKm: Double? = nil       // 剩余距离 km
    var navArrivalSoc: Int? = nil        // 到达预计电量 %
    var navRoad: String? = nil           // 当前路段名
    var navTurn: String? = nil           // 下一步转向文字
    var navExit: String? = nil           // 出口编号

    /// 是否超速（按设置的阈值）
    func isOverspeed(mode: AppSettings.ThresholdMode, value: Double) -> Bool {
        guard let limit = speedLimitKmh, let speed = speedKmh else { return false }
        switch mode {
        case .fixed:   return speed > Double(limit) + value
        case .percent: return speed > Double(limit) * (1 + value / 100)
        }
    }

    // MARK: - 本趟行程统计（App 本地累计）
    private(set) var tripStart: Date? = nil
    private(set) var tripDistanceKm: Double = 0
    private(set) var tripEnergyKwh: Double = 0
    private var lastOdometerForTrip: Double? = nil
    private var lastEnergyTimestamp: Date? = nil

    var tripDuration: TimeInterval {
        guard let start = tripStart else { return 0 }
        return Date().timeIntervalSince(start)
    }

    var tripAverageSpeedKmh: Double? {
        let hours = tripDuration / 3600
        guard hours > 0.001 else { return nil }
        return tripDistanceKm / hours
    }

    /// 把解析出的 TITA 数据帧写入全局状态（连接层共用入口）
    func apply(_ frame: TitaFrame) {
        if let v = frame.batteryPercent { batteryPercent = v }
        if let v = frame.rangeKm       { rangeKm = v }
        if let v = frame.outsideTempC  { outsideTempC = v }
        if let v = frame.insideTempC   { insideTempC = v }
        if let v = frame.leftTurnSignal  { leftTurnSignal = v }
        if let v = frame.rightTurnSignal { rightTurnSignal = v }
        if let v = frame.autopilotActive { autopilotActive = v }
        if let v = frame.blindSpotLeft   { blindSpotLeft = v }
        if let v = frame.blindSpotRight  { blindSpotRight = v }
        if let v = frame.tirePressure    { tirePressure = v }
        if let v = frame.tireTemperature { tireTemperature = v }
        if let v = frame.brakeActive     { brakeActive = v }
        if let v = frame.speedLimitKmh   { speedLimitKmh = v }
        if let v = frame.seatbeltFastened { seatbeltFastened = v }
        if let v = frame.trafficLight    { trafficLight = (v == "none" ? nil : v) }
        if let v = frame.doorAjar        { doorAjar = v }
        if let v = frame.headlightsOn    { headlightsOn = v }
        if let v = frame.hazardOn        { hazardOn = v }
        if let v = frame.autoholdActive  { autoholdActive = v }
        if let v = frame.trunkOpen       { trunkOpen = v }
        if let v = frame.frunkOpen       { frunkOpen = v }
        if let v = frame.espActive       { espActive = v }
        if let v = frame.navEta        { navEta = v }
        if let v = frame.navRemainKm   { navRemainKm = v }
        if let v = frame.navArrivalSoc { navArrivalSoc = v }
        if let v = frame.navRoad       { navRoad = v }
        if let v = frame.navTurn       { navTurn = v }
        if let v = frame.navExit       { navExit = v }
        ingestFrame(speed: frame.speedKmh, gear: frame.gear,
                    odometer: frame.odometerKm, powerKw: frame.powerKw)
    }

    /// 每收到一帧实时数据时调用，驱动行程统计
    func ingestFrame(speed: Double?, gear: Gear?, odometer: Double?, powerKw: Double?) {
        if let speed { self.speedKmh = speed }
        if let gear {
            // 离开 P 档开始计趟，回 P 档结束
            if self.gear == .park || self.gear == nil, gear != .park {
                startTripIfNeeded()
            } else if gear == .park, self.gear != .park {
                endTrip()
            }
            self.gear = gear
        }
        if let odometer {
            self.odometerKm = odometer
            if let last = lastOdometerForTrip, odometer > last, tripStart != nil {
                tripDistanceKm += odometer - last
            }
            lastOdometerForTrip = odometer
        }
        if let powerKw, tripStart != nil {
            let now = Date()
            if let t = lastEnergyTimestamp {
                let dt = now.timeIntervalSince(t) / 3600 // 小时
                if dt > 0, powerKw > 0 { // 只统计驱动耗电，不计回收
                    tripEnergyKwh += powerKw * dt
                }
            }
            lastEnergyTimestamp = now
            self.powerKw = powerKw
        }
    }

    private func startTripIfNeeded() {
        guard tripStart == nil else { return }
        tripStart = Date()
        tripDistanceKm = 0
        tripEnergyKwh = 0
        lastEnergyTimestamp = Date()
    }

    private func endTrip() {
        tripStart = nil
        lastEnergyTimestamp = nil
    }

    /// 手动清零本趟
    func resetTrip() {
        tripStart = nil
        tripDistanceKm = 0
        tripEnergyKwh = 0
        lastEnergyTimestamp = nil
    }

    /// 断开连接时清空实时数据，恢复 “--” 占位
    func clearRealtime() {
        speedKmh = nil
        gear = nil
        batteryPercent = nil
        rangeKm = nil
        odometerKm = nil
        outsideTempC = nil
        insideTempC = nil
        powerKw = nil
        leftTurnSignal = false
        rightTurnSignal = false
        autopilotActive = false
        blindSpotLeft = false
        blindSpotRight = false
        tirePressure = []
        tireTemperature = []
        brakeActive = false
        speedLimitKmh = nil
        seatbeltFastened = nil
        trafficLight = nil
        doorAjar = false
        headlightsOn = false
        hazardOn = false
        autoholdActive = false
        trunkOpen = false
        frunkOpen = false
        espActive = false
        navEta = nil
        navRemainKm = nil
        navArrivalSoc = nil
        navRoad = nil
        navTurn = nil
        navExit = nil
        endTrip()
    }
}
