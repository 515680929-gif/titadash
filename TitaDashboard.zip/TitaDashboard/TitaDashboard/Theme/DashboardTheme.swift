import SwiftUI

/// 仪表盘全局视觉常量（配色参照 Dashla 资源表 + 视频取色）
enum DashboardTheme {
    static let background = Color.black
    static let panelBackground = Color(white: 0.08)
    static let ringTrack = Color(white: 0.16)
    static let primaryText = Color.white
    static let secondaryText = Color(white: 0.55)
    static let placeholder = Color(white: 0.35)

    static let accentGreen = Color(red: 0.30, green: 0.85, blue: 0.45)   // 正常电量
    static let accentOrange = Color(red: 1.00, green: 0.62, blue: 0.10)  // 低电量
    static let accentRed = Color(red: 0.95, green: 0.30, blue: 0.25)     // 告警

    // Dashla 信号灯专用色
    static let signalBlue = Color(red: 0.20, green: 0.55, blue: 1.00)    // AP 蓝
    static let signalGreen = Color(red: 0.20, green: 0.95, blue: 0.45)   // 转向/通行绿
    static let signalAmber = Color(red: 1.00, green: 0.78, blue: 0.12)   // 盲点/黄灯
    static let signalRed = Color(red: 1.00, green: 0.25, blue: 0.22)     // 刹车/告警红

    static let gearActive = Color.white
    static let gearInactive = Color(white: 0.32)

    /// 彩虹速度弧渐变（Dashla speedometerrainbowpreview：绿→黄→橙→红）
    static let speedRainbow = AngularGradient(
        gradient: Gradient(colors: [
            Color(red: 0.16, green: 0.90, blue: 0.45),
            Color(red: 0.75, green: 0.95, blue: 0.25),
            Color(red: 1.00, green: 0.78, blue: 0.15),
            Color(red: 1.00, green: 0.48, blue: 0.12),
            Color(red: 1.00, green: 0.25, blue: 0.22)
        ]),
        center: .center,
        startAngle: .degrees(0),
        endAngle: .degrees(270)
    )

    /// 数字使用等宽字体，避免刷新时抖动
    static func monoDigit(size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .rounded).monospacedDigit()
    }

    static func batteryColor(for percent: Int?) -> Color {
        guard let p = percent else { return placeholder }
        if p <= 15 { return accentRed }
        if p <= 30 { return accentOrange }
        return accentGreen
    }
}
