import SwiftUI

/// 仪表盘全局视觉常量
enum DashboardTheme {
    static let background = Color.black
    static let panelBackground = Color(white: 0.08)
    static let ringTrack = Color(white: 0.18)
    static let primaryText = Color.white
    static let secondaryText = Color(white: 0.55)
    static let placeholder = Color(white: 0.35)

    static let accentGreen = Color(red: 0.30, green: 0.85, blue: 0.45)   // 正常电量
    static let accentOrange = Color(red: 1.00, green: 0.62, blue: 0.10)  // 低电量
    static let accentRed = Color(red: 0.95, green: 0.30, blue: 0.25)     // 告警
    static let gearActive = Color.white
    static let gearInactive = Color(white: 0.35)

    /// 数字使用等宽字体，避免刷新时抖动
    static func monoDigit(size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .rounded).monospacedDigit()
    }

    static func batteryColor(for percent: Int?) -> Color {
        guard let p = percent else { return placeholder }
        if p <= 15 { return accentRed }
        if p <= 30 { return accentOrange }
        return accentGreen
    }
}
