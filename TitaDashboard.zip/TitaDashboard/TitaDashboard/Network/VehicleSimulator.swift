import Foundation
import Observation

/// 模拟数据源：无 TITA 硬件时用于 UI 调试。
/// 生成一段「起步 → 加速 → 巡航 → 减速 → 停车」的循环数据。
@Observable
final class VehicleSimulator {
    private(set) var isRunning = false
    private var task: Task<Void, Never>?
    private let vehicleState: VehicleState

    private var phase: Double = 0
    private var odo: Double = 61_234.0
    private var battery = 78
    private var consumed: Double = 0

    init(vehicleState: VehicleState) {
        self.vehicleState = vehicleState
    }

    func start() {
        guard !isRunning else { return }
        isRunning = true
        vehicleState.batteryPercent = battery
        vehicleState.rangeKm = Double(battery) * 5.2
        vehicleState.odometerKm = odo
        vehicleState.outsideTempC = 23.5
        vehicleState.insideTempC = 21.0
        // 模拟四轮胎压/温度
        vehicleState.tirePressure = [2.4, 2.4, 2.35, 2.35]
        vehicleState.tireTemperature = [28, 29, 27, 28]
        // 模拟导航详情
        vehicleState.navRoad = "沪昆高速"
        vehicleState.navTurn = "前方 2 公里，从 31 号出口下，往市区方向"
        vehicleState.navExit = "31"
        vehicleState.navRemainKm = 42.6
        vehicleState.navArrivalSoc = 56
        let fmt = DateFormatter(); fmt.dateFormat = "HH:mm"
        vehicleState.navEta = fmt.string(from: Date().addingTimeInterval(2400))
        // 模拟车灯（随巡航阶段开大灯）
        vehicleState.headlightsOn = false
        vehicleState.speedLimitKmh = 120

        task = Task { [weak self] in
            while !Task.isCancelled {
                guard let self else { return }
                try? await Task.sleep(for: .milliseconds(100)) // 10Hz 刷新
                await MainActor.run { self.tick() }
            }
        }
    }

    func stop() {
        task?.cancel(); task = nil
        isRunning = false
        vehicleState.clearRealtime()
    }

    private func tick() {
        phase += 0.004
        // 速度曲线：0 → 80 → 巡航波动 → 回 0，周期循环
        let cycle = phase.truncatingRemainder(dividingBy: 1.0)
        let speed: Double
        switch cycle {
        case 0..<0.3:  speed = 80 * (cycle / 0.3)                    // 加速
        case 0.3..<0.7: speed = 80 + sin(phase * 20) * 3             // 巡航
        case 0.7..<0.95: speed = 80 * (1 - (cycle - 0.7) / 0.25)     // 减速
        default:       speed = 0                                     // 停车
        }

        let gear: Gear = speed > 0.5 ? .drive : .park
        odo += speed / 36000 // 100ms 前进的里程

        // 简单能耗模型
        let power = speed > 1 ? max(0, 8 + speed * 0.12) : 0
        consumed += power / 36000
        if consumed > 0.5 {
            battery = max(5, battery - 1)
            consumed = 0
            vehicleState.batteryPercent = battery
            vehicleState.rangeKm = Double(battery) * 5.2
        }

        vehicleState.leftTurnSignal = cycle > 0.62 && cycle < 0.7 && Int(phase * 100) % 2 == 0
        // 巡航阶段（傍晚）自动开大灯；刹车阶段点亮刹车灯
        vehicleState.headlightsOn = cycle > 0.3 && cycle < 0.7
        vehicleState.brakeActive = cycle > 0.7 && cycle < 0.95
        // 导航剩余距离随里程递减
        if (vehicleState.navRemainKm ?? 0) > 0 {
            vehicleState.navRemainKm = max(0, (vehicleState.navRemainKm ?? 0) - speed / 36000)
        }
        vehicleState.ingestFrame(speed: speed, gear: gear, odometer: odo, powerKw: power)
    }
}
