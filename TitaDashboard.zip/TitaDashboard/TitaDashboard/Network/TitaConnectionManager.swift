import Foundation
import Network
import Observation

enum ConnectionStatus: Equatable {
    case disconnected
    case connecting
    case connected
    case failed(String)

    var displayText: String {
        switch self {
        case .disconnected:     return "未连接"
        case .connecting:       return "连接中…"
        case .connected:        return "已连接"
        case .failed(let msg):  return "连接失败：\(msg)"
        }
    }
}

/// TITA 发射器连接管理器
/// 负责：建立 WebSocket 连接、接收数据帧、心跳保活、断线自动重连。
@Observable
final class TitaConnectionManager {
    private(set) var status: ConnectionStatus = .disconnected
    private(set) var lastFrameTime: Date? = nil
    /// 最近收到的原始帧文本（用于配对页调试日志）
    private(set) var debugLog: [String] = []

    /// 发射器热点网关地址；第二路协议端口以实际抓包为准（默认 8080，可在设置中修改）
    var host: String = "4.3.2.1"
    var port: UInt16 = 8080
    var path: String = "/ws"
    var autoReconnect = true

    private var connection: NWConnection?
    private let queue = DispatchQueue(label: "com.titadashboard.conn", qos: .userInitiated)
    private var reconnectTask: Task<Void, Never>?
    private var heartbeatTask: Task<Void, Never>?
    private let vehicleState: VehicleState

    init(vehicleState: VehicleState) {
        self.vehicleState = vehicleState
    }

    // MARK: - 连接控制

    func connect() {
        disconnect(clearState: false)
        status = .connecting
        log("尝试连接 ws://\(host):\(port)\(path)")

        let endpoint = NWEndpoint.hostPort(
            host: NWEndpoint.Host(host),
            port: NWEndpoint.Port(rawValue: port)!
        )
        let params = NWParameters.tcp
        // WebSocket 协议栈
        let wsOptions = NWProtocolWebSocket.Options()
        wsOptions.autoReplyPing = true
        params.defaultProtocolStack.applicationProtocols.insert(wsOptions, at: 0)

        let conn = NWConnection(to: endpoint, using: params)
        connection = conn

        conn.stateUpdateHandler = { [weak self] state in
            guard let self else { return }
            Task { @MainActor in
                switch state {
                case .ready:
                    self.status = .connected
                    self.log("连接成功，等待数据帧…")
                    self.receiveLoop()
                    self.startHeartbeat()
                case .failed(let error):
                    self.status = .failed(error.localizedDescription)
                    self.log("连接失败：\(error.localizedDescription)")
                    self.scheduleReconnect()
                case .cancelled:
                    break
                default:
                    break
                }
            }
        }
        conn.start(queue: queue)
    }

    func disconnect(clearState: Bool = true) {
        reconnectTask?.cancel(); reconnectTask = nil
        heartbeatTask?.cancel(); heartbeatTask = nil
        connection?.stateUpdateHandler = nil
        connection?.cancel()
        connection = nil
        status = .disconnected
        if clearState {
            Task { @MainActor in vehicleState.clearRealtime() }
        }
    }

    // MARK: - 接收循环

    private func receiveLoop() {
        connection?.receiveMessage { [weak self] content, context, isComplete, error in
            guard let self else { return }
            Task { @MainActor in
                if let error {
                    self.status = .failed(error.localizedDescription)
                    self.scheduleReconnect()
                    return
                }
                if let data = content {
                    // 通过 WebSocket metadata 判断是否为文本帧；失败则按原始数据处理
                    var isText = false
                    if let metadata = context?.protocolMetadata(
                        first: NWProtocolWebSocket.Metadata.self) {
                        if case .text = metadata.opcode { isText = true }
                    }
                    self.handleMessage(data: data, isText: isText)
                }
                self.receiveLoop() // 持续接收
            }
        }
    }

    private func handleMessage(data: Data, isText: Bool) {
        lastFrameTime = Date()
        var frame: TitaFrame?

        if let text = String(data: data, encoding: .utf8),
           let parsed = TitaFrameParser.parse(text: text) {
            frame = parsed
            log(text, maxKeep: 200)
        } else if let parsed = TitaFrameParser.parse(binary: data) {
            frame = parsed
        }
        guard let frame else { return }

        // 写入全局状态
        if let v = frame.batteryPercent { vehicleState.batteryPercent = v }
        if let v = frame.rangeKm       { vehicleState.rangeKm = v }
        if let v = frame.outsideTempC  { vehicleState.outsideTempC = v }
        if let v = frame.insideTempC   { vehicleState.insideTempC = v }
        if let v = frame.leftTurnSignal  { vehicleState.leftTurnSignal = v }
        if let v = frame.rightTurnSignal { vehicleState.rightTurnSignal = v }
        if let v = frame.autopilotActive { vehicleState.autopilotActive = v }
        if let v = frame.blindSpotLeft   { vehicleState.blindSpotLeft = v }
        if let v = frame.blindSpotRight  { vehicleState.blindSpotRight = v }
        if let v = frame.tirePressure    { vehicleState.tirePressure = v }
        if let v = frame.brakeActive     { vehicleState.brakeActive = v }
        if let v = frame.speedLimitKmh   { vehicleState.speedLimitKmh = v }
        if let v = frame.seatbeltFastened { vehicleState.seatbeltFastened = v }
        if let v = frame.trafficLight    { vehicleState.trafficLight = (v == "none" ? nil : v) }
        if let v = frame.doorAjar        { vehicleState.doorAjar = v }
        vehicleState.ingestFrame(
            speed: frame.speedKmh,
            gear: frame.gear,
            odometer: frame.odometerKm,
            powerKw: frame.powerKw
        )
    }

    // MARK: - 心跳 & 自动重连

    private func startHeartbeat() {
        heartbeatTask?.cancel()
        heartbeatTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(5))
                guard let self, !Task.isCancelled else { return }
                // 10 秒无数据则认为链路异常，主动重连
                if let last = await MainActor.run(body: { self.lastFrameTime }),
                   Date().timeIntervalSince(last) > 10 {
                    await MainActor.run {
                        self.log("数据超时，触发重连")
                        self.connect()
                    }
                    return
                }
            }
        }
    }

    private func scheduleReconnect() {
        guard autoReconnect, reconnectTask == nil else { return }
        reconnectTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(3))
            guard let self, !Task.isCancelled else { return }
            await MainActor.run { self.reconnectTask = nil; self.connect() }
        }
    }

    // MARK: - 调试日志

    private func log(_ message: String, maxKeep: Int = 100) {
        let stamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        debugLog.append("[\(stamp)] \(message)")
        if debugLog.count > maxKeep { debugLog.removeFirst(debugLog.count - maxKeep) }
    }
}
