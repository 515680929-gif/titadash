import Foundation

// MARK: - 字段映射（★ 真机联调时按发射器实际推送的 key 修改这里即可）
/// TITA 官方未公开第二路协议字段文档，此处 key 为常见命名约定，
/// 请通过「连接测试」页的原始日志确认实际字段名后在此集中替换。
enum FieldKey {
    static let speed        = "speed"        // 车速 km/h
    static let gear         = "gear"         // 档位 "P"/"R"/"N"/"D" 或数字 0-3
    static let battery      = "soc"          // 电量 %
    static let range        = "range"        // 续航 km
    static let odometer     = "odo"          // 总里程 km
    static let outsideTemp  = "temp_out"     // 车外温度 ℃
    static let insideTemp   = "temp_in"      // 车内温度 ℃
    static let power        = "power"        // 功率 kW
    static let leftSignal   = "turn_l"
    static let rightSignal  = "turn_r"
    static let autopilot    = "ap"
    static let blindLeft    = "bs_l"
    static let blindRight   = "bs_r"
    static let tirePressure = "tpms"         // [FL, FR, RL, RR] bar
    static let brake        = "brake"        // 刹车踏板 0/1
    static let speedLimit   = "speed_limit"  // 道路限速 km/h（TITA 专属信号）
    static let seatbelt     = "seatbelt"     // 主驾安全带 1=已系
    static let trafficLight = "traffic_light"// 红绿灯状态 "red"/"green"/"none"
    static let doorAjar     = "door"         // 车门未关 0/1
}

// MARK: - 解码后的统一数据帧
struct TitaFrame {
    var speedKmh: Double?
    var gear: Gear?
    var batteryPercent: Int?
    var rangeKm: Double?
    var odometerKm: Double?
    var outsideTempC: Double?
    var insideTempC: Double?
    var powerKw: Double?
    var leftTurnSignal: Bool?
    var rightTurnSignal: Bool?
    var autopilotActive: Bool?
    var blindSpotLeft: Bool?
    var blindSpotRight: Bool?
    var tirePressure: [Double]?
    var brakeActive: Bool?
    var speedLimitKmh: Int?
    var seatbeltFastened: Bool?
    var trafficLight: String?      // "red" / "green" / "none"
    var doorAjar: Bool?
}

// MARK: - 帧解析器
enum TitaFrameParser {

    /// 解析一帧文本消息（JSON）。返回 nil 表示无法识别（可能是心跳/握手包）。
    static func parse(text: String) -> TitaFrame? {
        guard let data = text.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return nil }
        return parse(json: obj)
    }

    static func parse(json: [String: Any]) -> TitaFrame {
        var frame = TitaFrame()
        frame.speedKmh      = num(json[FieldKey.speed])
        frame.gear          = parseGear(json[FieldKey.gear])
        frame.batteryPercent = num(json[FieldKey.battery]).map { Int($0.rounded()) }
        frame.rangeKm       = num(json[FieldKey.range])
        frame.odometerKm    = num(json[FieldKey.odometer])
        frame.outsideTempC  = num(json[FieldKey.outsideTemp])
        frame.insideTempC   = num(json[FieldKey.insideTemp])
        frame.powerKw       = num(json[FieldKey.power])
        frame.leftTurnSignal  = bool(json[FieldKey.leftSignal])
        frame.rightTurnSignal = bool(json[FieldKey.rightSignal])
        frame.autopilotActive = bool(json[FieldKey.autopilot])
        frame.blindSpotLeft   = bool(json[FieldKey.blindLeft])
        frame.blindSpotRight  = bool(json[FieldKey.blindRight])
        frame.brakeActive     = bool(json[FieldKey.brake])
        frame.speedLimitKmh   = num(json[FieldKey.speedLimit]).map { Int($0) }
        frame.seatbeltFastened = bool(json[FieldKey.seatbelt])
        frame.trafficLight    = json[FieldKey.trafficLight] as? String
        frame.doorAjar        = bool(json[FieldKey.doorAjar])
        if let arr = json[FieldKey.tirePressure] as? [Any] {
            frame.tirePressure = arr.compactMap { num($0) }
        }
        return frame
    }

    /// 二进制帧入口：若发射器推送的是二进制协议，在此按字节偏移解析。
    static func parse(binary data: Data) -> TitaFrame? {
        // TODO: 真机抓包后实现二进制解析，例如：
        // guard data.count >= 8 else { return nil }
        // var frame = TitaFrame()
        // frame.speedKmh = Double(data[1]) * 0.5
        // ...
        _ = data
        return nil
    }

    // MARK: - 工具
    private static func num(_ any: Any?) -> Double? {
        switch any {
        case let n as NSNumber: return n.doubleValue
        case let s as String:   return Double(s)
        default:                return nil
        }
    }

    private static func bool(_ any: Any?) -> Bool? {
        switch any {
        case let n as NSNumber: return n.boolValue
        case let s as String:   return ["1", "true", "on"].contains(s.lowercased())
        default:                return nil
        }
    }

    private static func parseGear(_ any: Any?) -> Gear? {
        switch any {
        case let s as String:
            return Gear(rawValue: s.uppercased())
        case let n as NSNumber:
            // 部分固件用数字：0=P 1=R 2=N 3=D
            return [Gear.park, .reverse, .neutral, .drive][safe: n.intValue]
        default:
            return nil
        }
    }
}

private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
