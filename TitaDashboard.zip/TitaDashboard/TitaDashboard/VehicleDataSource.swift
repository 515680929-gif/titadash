import Foundation

/// Abstraction between the dashboard UI and the source of vehicle telemetry.
/// The current build feeds this interface with demo values. A future TITA
/// CoreBluetooth decoder can implement the same contract without changing UI.
@MainActor protocol VehicleDataSource: AnyObject {
    var latestSnapshot: VehicleSnapshot { get }
}

/// Documented contract for the future TITA transport layer.
/// UUIDs and packet decoding must be filled from verified TITA protocol data;
/// no guessed service or characteristic UUIDs are embedded in this project.
@MainActor protocol TITADeviceTransport: AnyObject {
    var connectionDescription: String { get }
    func beginDiscovery()
    func disconnect()
}

extension VehicleStore: VehicleDataSource {
    var latestSnapshot: VehicleSnapshot { data }
}
