import SwiftUI

@main
struct TitaDashboardApp: App {
    @State private var vehicleState = VehicleState()
    @State private var connectionManager: TitaConnectionManager

    init() {
        let state = VehicleState()
        _vehicleState = State(initialValue: state)
        _connectionManager = State(initialValue: TitaConnectionManager(vehicleState: state))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(vehicleState)
                .environment(connectionManager)
                .preferredColorScheme(.dark)
                .persistentSystemOverlays(.hidden) // 仪表盘全屏沉浸式
        }
    }
}
