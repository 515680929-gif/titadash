import SwiftUI

@main
struct DashlaApp: App {
    @StateObject private var vehicle = VehicleStore()
    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(vehicle)
                .preferredColorScheme(.dark)
        }
    }
}
